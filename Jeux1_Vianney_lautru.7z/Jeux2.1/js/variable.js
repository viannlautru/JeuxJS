var power = true
var powerfirst = true
var premierefois = true
var premierefoisjeux = true
var i = 0
var menuopen = true
var menuglob = true
var menuPrincipale = true
var sousmenu = false
var menusetting = false
var menuTouche = false
var menuMonde = false
var map = false
var miseenpause = false
let timer
var timermin = 00
var oldtimer = 00
var timesec = 00
var scrorefinaux = 0

var fenetreheight
var fenetrewhidth

var ok1 = false
var ok2 = false
var ok3 = false
var TUTORIEL = false
var suivant = false
var niv1
var niv2
var niv3
var niv4

var avancerT = 68
var avancerlettre = "d"
var TOUCHE1 = false
var reculerT = 81
var reculerlettre = "q"
var TOUCHE2 = false
var sauterT = 90
var sauterlettre = "z"
var TOUCHE3 = false
var taperT = 69
var taperlettre = "e"
var TOUCHE4 = false
var perso1 = false
var deplacement = 0
var deplacementpers = 0
var attaque = true
var bouclier = false
var bouclierutilisation = 0
var up = false

var ingamesound = new Audio("./sound/ingame.mp3")
var outgamesound = new Audio("./sound/outgame.mp3")
var dead = new Audio("./sound/dead.mp3")
var quit = new Audio("./sound/quit.mp3")
var navig = new Audio("./sound/navig.mp3")
var navig2 = new Audio("./sound/navig.mp3")
var navig3 = new Audio("./sound/navig.mp3")
var boucliercoup = new Audio("./sound/contactebouc.mp3")
var bouclierprise = new Audio("./sound/soundbouclier.mp3")
var tapersoud = new Audio("./sound/taper.mp3")

var valid = new Audio("./sound/valid.mp3")


var died = false
var choix = 1
var difficulte = 50
var mechant = false
let mouvementenemie
let aleaenemi
var nombredemechantcontant = 0;
var nombredemechanttotal = 0;
var asupp = false
//LES IMAGES PAR SECONDES
let nl = [2, 3, 1, 4, 5, 1];
//____________________________________INITIALISATION DES IMAGES PERSONNAGE-MECHANT-ARME-DECORS____________________________
//-------LE DOSSIER----------
var img = "img/design1/"
//----------LES IMAGES------------
var imgsol = document.createElement("img");
var imgPersonnage = document.createElement("img");
var imgarme = document.createElement("img");
var imgbouclier = document.createElement("img");
var imgbuissonG = document.createElement("img");
var imgbuissonD = document.createElement("img");
var imgciel = document.createElement("img");
var design = document.createElement("img");
design.src = img + "personnage1.png";



//____________________________________INITIALISATION DES ID____________________________
document.getElementById("avancerP").innerHTML = avancerlettre;
document.getElementById("reculerP").innerHTML = reculerlettre;
document.getElementById("sauterP").innerHTML = sauterlettre;
document.getElementById("taperrP").innerHTML = taperlettre;
document.getElementById("pause").style.display = "none";
document.getElementById("menu").style.margin = ""
document.getElementById("menu").style.padding = "8% 5% 8% 5%"
document.getElementById("Lejeux").style.display = "none"
document.getElementById("gris").style.display = "none";
document.getElementById("timer").style.display = "none";
document.getElementById("Score").style.display = "none";
document.getElementById("tutotexte").style.display = "none";
document.getElementById("Setting").style.display = "none";
document.getElementById("Mondes").style.display = "none";
document.getElementById("touches").style.display = "none";