async function Clavier(e) {

    var keynum;
    if (window.event) // IE
    {
        keynum = e.keyCode;
    }
    else if (e.which) // Netscape/Firefox/Opera
    {
        keynum = e.which;
    }
    if (keynum && powerfirst) {
        power = false
        powerfirst = false
        outgamesound.play();
        document.getElementById('power').style.display="none"
    }
    if (!power) {
    console.log(keynum)
    if (keynum == 84) {
        nombredemechanttotal += 1
    }
    if (keynum == 89) {
        nombredemechanttotal -= 1
    }
    if (keynum == 66) {
        bouclieritem()
    }
    if (TOUCHE1) {
        if (keynum) {
            TOUCHE1 = false
        }
        console.log(event.key)
        document.getElementById('avancerP').innerHTML = "" + event.key + ""
        avancerT = keynum
    }
    if (TOUCHE2) {
        if (keynum) {
            TOUCHE2 = false
        }
        console.log(event.key)
        document.getElementById('reculerP').innerHTML = "" + event.key + ""
        reculerT = keynum
    }
    if (TOUCHE3) {
        if (keynum) {
            TOUCHE3 = false
        }
        console.log(event.key)
        document.getElementById('sauterP').innerHTML = "" + event.key + ""
        sauterT = keynum
    }
    if (TOUCHE4) {
        if (keynum) {
            TOUCHE4 = false
        }
        console.log(event.key)
        document.getElementById('taperrP').innerHTML = "" + event.key + ""
        taperT = keynum
    }

    //alert(keynum);
    if (keynum == 27) {
        if (miseenpause) {
            Continuer()
        } else {
            echap()
        }
    }
    if (menuglob) {
        //-----------------------------------------------------------menu-----------------------------------------------------------------------------
        if ((keynum == 90 || keynum == 83 || keynum == 81 || keynum == 68)) {
            document.getElementById("commencer").style.textDecoration = "none";
            document.getElementById("setting").style.textDecoration = "none";
            document.getElementById("touche").style.textDecoration = "none";
            document.getElementById("monde").style.textDecoration = "none";
            document.getElementById("TUTO").style.textDecoration = "none";
            document.getElementById("monde").style.fontSize = "2.8vw";
            document.getElementById("touche").style.fontSize = "2.8vw";
            document.getElementById("commencer").style.fontSize = "2.8vw";
            document.getElementById("setting").style.fontSize = "2.8vw";
            document.getElementById("TUTO").style.fontSize = "2.8vw";
            document.getElementById("Continuer").style.textDecoration = "none";
            document.getElementById("quit").style.textDecoration = "none";
            document.getElementById("Continuer").style.fontSize = "2.8vw";
            document.getElementById("quit").style.fontSize = "2.8vw";

            document.getElementById("validemonde").style.fontSize = "2.8vw";
            document.getElementById("validemonde").style.textDecoration = "none";
            document.getElementById("toucheav").style.fontSize = "2.8vw";
            document.getElementById("toucheav").style.textDecoration = "none";
            document.getElementById("touchere").style.fontSize = "2.8vw";
            document.getElementById("touchere").style.textDecoration = "none";
            document.getElementById("touchesa").style.fontSize = "2.8vw";
            document.getElementById("touchesa").style.textDecoration = "none";
            document.getElementById("toucheta").style.fontSize = "2.8vw";
            document.getElementById("toucheta").style.textDecoration = "none";
            document.getElementById("valide").style.fontSize = "2.8vw";
            document.getElementById("valide").style.textDecoration = "none";

            if (menuopen == true) {
                if (menuPrincipale == true) {
                    if (keynum == 90) {
                        i--
                        if (i < 0) {
                            i = 2
                        }
                    } else if (keynum == 83) {
                        i++
                        if (i > 2) {
                            i = 0
                        }
                    }
                    if (premierefois) {
                        i = 0
                        premierefois = false
                    }
                    switch (i) {
                        case 0:
                            navig.play();
                            document.getElementById("commencer").style.textDecoration = "underline";
                            document.getElementById("commencer").style.fontSize = "3vw";
                            console.log("1")
                            break;
                        case 1:
                            navig2.play();
                            document.getElementById("setting").style.textDecoration = "underline";
                            document.getElementById("setting").style.fontSize = "3vw";
                            console.log("2")
                            break;
                        case 2:
                            navig3.play();
                            document.getElementById("TUTO").style.textDecoration = "underline";
                            document.getElementById("TUTO").style.fontSize = "3vw";
                            console.log("3")
                            break;
                    }
                } else if (sousmenu == true) {
                    if (menusetting == true) {
                        if (keynum == 90) {
                            i--
                            if (i < 0) {
                                i = 1
                            }
                        } else if (keynum == 83) {
                            i++
                            if (i > 1) {
                                i = 0
                            }
                        }
                        if (premierefois) {
                            i = 0
                            premierefois = false
                        }
                        switch (i) {
                            case 0:
                                navig.play();
                                document.getElementById("touche").style.textDecoration = "underline";
                                document.getElementById("touche").style.fontSize = "3vw";
                                console.log("1")
                                break;
                            case 1:
                                navig2.play();
                                document.getElementById("monde").style.textDecoration = "underline";
                                document.getElementById("monde").style.fontSize = "3vw";
                                console.log("2")
                                break;
                        }
                    } else if (menuTouche == true) {
                        if (keynum == 90) {
                            i--
                            if (i < 0) {
                                i = 4
                            }
                        } else if (keynum == 83) {
                            i++
                            if (i > 4) {
                                i = 0
                            }
                        }
                        if (premierefois) {
                            i = 0
                            premierefois = false
                        }
                        switch (i) {
                            case 0:
                                navig.play();
                                document.getElementById("toucheav").style.textDecoration = "underline";
                                document.getElementById("toucheav").style.fontSize = "3vw";
                                console.log("1")
                                break;
                            case 1:
                                navig2.play();
                                document.getElementById("touchere").style.textDecoration = "underline";
                                document.getElementById("touchere").style.fontSize = "3vw";
                                console.log("2")
                                break;
                            case 2:
                                navig3.play();
                                document.getElementById("touchesa").style.textDecoration = "underline";
                                document.getElementById("touchesa").style.fontSize = "3vw";
                                console.log("3")
                                break;
                            case 3:
                                navig.play();
                                document.getElementById("toucheta").style.textDecoration = "underline";
                                document.getElementById("toucheta").style.fontSize = "3vw";
                                console.log("4")
                                break;
                            case 4:
                                navig2.play();
                                document.getElementById("valide").style.textDecoration = "underline";
                                document.getElementById("valide").style.fontSize = "3vw";
                                console.log("5")
                                break;
                        }
                    } else if (menuMonde == true) {
                        if (keynum == 81) {
                            precedentM()
                        } else if (keynum == 68) {
                            suivantM()
                        }
                        if (keynum == 90) {
                            i--
                            if (i < 0) {
                                i = 1
                            }
                        } else if (keynum == 83) {
                            i++
                            if (i > 1) {
                                i = 0
                            }
                        }
                        if (premierefois) {
                            i = 0
                            premierefois = false
                        }
                        switch (i) {
                            case 0:
                                navig.play();
                                document.getElementById("validemonde").style.textDecoration = "underline";
                                document.getElementById("validemonde").style.fontSize = "3vw";
                                console.log("5")
                                break;
                            case 1:

                                break;
                        }
                    }
                }
            } else {
                console.log("pause")
                if (keynum == 90) {
                    i--
                    if (i < 0) {
                        i = 1
                    }
                } else if (keynum == 83) {
                    i++
                    if (i > 1) {
                        i = 0
                    }
                }
                if (premierefois) {
                    i = 0
                    premierefois = false
                }
                switch (i) {
                    case 0:
                        document.getElementById("Continuer").style.textDecoration = "underline";
                        document.getElementById("Continuer").style.fontSize = "3vw";
                        console.log("1")
                        break;
                    case 1:
                        document.getElementById("quit").style.textDecoration = "underline";
                        document.getElementById("quit").style.fontSize = "3vw";
                        console.log("2")
                        break;
                }
            }
        }
        if (keynum == 13) {
            valid.play()
            if (menuopen == true) {
                if (menuPrincipale == true) {
                    switch (i) {
                        case 0:
                            commencer()
                            TUTORIEL=false
                            break;
                        case 1:
                            setting()
                            menuPrincipale = false
                            menusetting = true
                            sousmenu = true
                            break;
                        case 2:
                            TUTO()
                            break;
                    }
                } else if (sousmenu == true) {
                    if (menusetting == true) {
                        switch (i) {
                            case 0:
                                menusetting = false
                                menuTouche = true
                                TOUCHE(0)
                                break;
                            case 1:
                                menusetting = false
                                menuMonde = true
                                MONDE()
                                break;
                        }

                    } else if (menuTouche == true) {
                        switch (i) {
                            case 0:
                                TOUCHE(1)
                                break;
                            case 1:
                                TOUCHE(2)
                                break;
                            case 2:
                                TOUCHE(3)
                                break;
                            case 3:
                                TOUCHE(4)
                                break;
                            case 4:
                                echap()
                                break;
                        }
                    } else if (menuMonde == true) {
                        switch (i) {
                            case 0:
                                echap()
                                break;
                        }
                    }
                }
            } else {
                if (i == 1) {
                    quit()
                } else if (i == 0) {
                    Continuer()
                }
            }
        }
        //-----------------------------------------------------------Finmenu-----------------------------------------------------------------------------
    } else if (perso1) {
        //-----------------------------------------------------------Mouvement perso-----------------------------------------------------------------------------

        if (keynum == avancerT) {
            var n = 1;
            while (n <= 2) {
                $('#personnage').offset({ left: $('#personnage').offset().left + avancer })
                $('#arme').offset({ left: $('#arme').offset().left + avancer })
                if (bouclier) {
                    $('#bouclier').offset({ left: $('#bouclier').offset().left + avancer })
                }
                Mouvementperso()
                await delay(300);

                n++;
                if ($('#personnage').offset().left > $('#buisson').offset().left) {
                    $('#personnage').offset({ left: $('#personnage').offset().left - (avancer + avancer) })
                    $('#arme').offset({ left: $('#arme').offset().left - (avancer + avancer) })
                    $('#bouclier').offset({ left: $('#bouclier').offset().left - (avancer + avancer) })
                }
                console.log($('#bouclier').offset())
                if (document.getElementById('bouclier') != null && $('#bouclier').offset().left + witdttouch >= $('#personnage').offset().left && $('#bouclier').offset().top - toptouch <= $('#personnage').offset().top && $('#bouclier').offset().left - witdttouch <= $('#personnage').offset().left && $('#bouclier').offset().top + toptouch >= $('#personnage').offset().top) {
                    if (TUTORIEL & niv1) {
                        niv1 = false
                        var n = 0;
                        while (n <= 5) {
                            nombredemechanttotal += 1;
                            await delay(250);
                            n++
                        }
                    }

                    if (!bouclier) {
                        bouclierprise.play()
                    }
                    bouclier = true
                    $('#bouclier').offset({ left: $('#personnage').offset().left + (avancer * 2.5) })
                    $('#bouclier').offset({ top: $('#personnage').offset().top })

                }
            }
        } else if (keynum == reculerT) {
            var n = 1;
            while (n <= 2) {
                $('#personnage').offset({ left: $('#personnage').offset().left - avancer })
                $('#arme').offset({ left: $('#arme').offset().left - avancer })
                if (bouclier) {
                    $('#bouclier').offset({ left: $('#bouclier').offset().left - avancer })
                }
                Mouvementperso()
                await delay(300);
                n++;
                if ($('#personnage').offset().left < $('#buissongauche').offset().left + avancer) {
                    $('#personnage').offset({ left: $('#personnage').offset().left + (avancer + avancer) })
                    $('#arme').offset({ left: $('#arme').offset().left + (avancer + avancer) })
                    $('#bouclier').offset({ left: $('#bouclier').offset().left + (avancer + avancer) })

                }
                if (document.getElementById('bouclier') != null && $('#bouclier').offset().left + witdttouch >= $('#personnage').offset().left && $('#bouclier').offset().top - toptouch <= $('#personnage').offset().top && $('#bouclier').offset().left - witdttouch <= $('#personnage').offset().left && $('#bouclier').offset().top + toptouch >= $('#personnage').offset().top) {
                    if (TUTORIEL & niv1) {
                        niv1 = false
                        var n = 0;
                        while (n <= 5) {
                            nombredemechanttotal += 1;
                            await delay(250);
                            n++
                        }
                    }
                    if (!bouclier) {
                        bouclierprise.play()
                    }
                    bouclier = true
                    $('#bouclier').offset({ left: $('#personnage').offset().left + (avancer * 3) })
                    $('#bouclier').offset({ top: $('#personnage').offset().top })
                }

            }
        } else if (keynum == 83 && keynum==187) {
            var n = 1;
            while (n <= 2) {
                $('#personnage').offset({ top: $('#personnage').offset().top + 1 })
                $('#arme').offset({ top: $('#arme').offset().top + 1 })
                if (bouclier) {
                    $('#bouclier').offset({ top: $('#bouclier').offset().top + 1 })
                }
                n++;
            }
        }
        if (keynum == sauterT) {
            var n = 1;
            if (!up) {
                up = true
                while (n <= 30) {
                    $('#personnage').offset({ top: $('#personnage').offset().top - sauter })
                    $('#arme').offset({ top: $('#arme').offset().top - sauter })
                    if (bouclier) {
                        $('#bouclier').offset({ top: $('#bouclier').offset().top - sauter })
                    }
                    await delay(15);
                    n++;
                }
                n = 1;
                await delay(15);
                while (n <= 30) {
                    $('#personnage').offset({ top: $('#personnage').offset().top + sauter })
                    $('#arme').offset({ top: $('#arme').offset().top + sauter })
                    if (bouclier) {
                        $('#bouclier').offset({ top: $('#bouclier').offset().top + sauter })
                    }
                    await delay(15);
                    n++;
                }
                document.getElementById("personnage").style.top = "";
                document.getElementById("arme").style.top = "";
                up = false
            }
        }
        //--------------------UTILISATION DE L'ARME---------------
        if (keynum == taperT) {
            if (document.getElementById('arme') != null) {
                if (attaque) {
                    attaque = false
                    tapersoud.play()
                    document.getElementById("arme").style.transform = "rotate(45deg)";
                    $('#arme').offset({ left: $('#arme').offset().left + avancer })
                    await delay(200);
                    document.getElementById("arme").style.transform = "rotate(90deg)";
                    $('#arme').offset({ left: $('#arme').offset().left + (avancer + avancer) })
                    await delay(200);
                    document.getElementById("arme").style.transform = "rotate(45deg)";
                    $('#arme').offset({ left: $('#arme').offset().left - (avancer + avancer) })
                    await delay(200);
                    $('#arme').offset({ left: $('#arme').offset().left - avancer })
                    document.getElementById("arme").style.transform = "rotate(340deg)";
                    attaqueready()
                }
            }

        }
        //----------------TUTO--------------
        if (TUTORIEL) {
            if (keynum == 82) {

                if (niv1) {
                    document.getElementById("tutotexte").style.display = "none";
                    await delay(250)
                    document.getElementById("tutotexte").style.display = "";
                    document.getElementById('Letexte').innerHTML = "Ca c'est toi, tu as vus comme tu es cool <br/> Maintenant si tu appuis sur E tu vas utiliser ta super arme"
                    joueur();
                    niv1 = false
                }
            }
            if (keynum == 69) {
                if (niv2 & !niv1) {
                    await delay(500);
                    document.getElementById("tutotexte").style.display = "none";
                    await delay(500);
                    document.getElementById("tutotexte").style.display = "";
                    document.getElementById('Letexte').innerHTML = "D�place toi avec les touches " + reculerlettre + sauterlettre + avancerlettre
                }
            }
            if (niv2 & !niv1) {
                if (keynum == 68) { ok1 = true }
                if (keynum == 81) { ok2 = true }
                if (keynum == 90) { ok3 = true }
                if (ok1 & ok2 & ok3) {
                    document.getElementById("tutotexte").style.display = "none";
                    await delay(250)
                    document.getElementById("tutotexte").style.display = "";
                    document.getElementById('Letexte').innerHTML = "Maintenant que tu sais tapper et bouger teste le sur lui "
                    nombredemechanttotal = 1
                    niv2 = false
                }
            }
            if (!niv3 & niv4) {
                document.getElementById("tutotexte").style.display = "none";
                await delay(250)
                document.getElementById("tutotexte").style.display = "";
                document.getElementById('Letexte').innerHTML = "Parfois des bouclier vons aparaitre sur le terrain ramasse le, celui-ci peut-encaisser 5 ennemis "
                bouclieritem()
                niv1 = true
                niv4 = false
            }
        }
        //-----------------------------------------------------------FinMouvement perso-----------------------------------------------------------------------------
    }
    }

}