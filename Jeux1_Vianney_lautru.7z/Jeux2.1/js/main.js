//____________________________________TAILLE ECRAN ADAPTATION____________________________
fenetreheight = window.innerHeight;
fenetrewhidth = window.innerWidth;
console.log(fenetreheight)
console.log(fenetrewhidth)
var witdttouch = fenetrewhidth / 50
var toptouch = fenetreheight / 20
//avancer de 10 grand �cran
var avancer = toptouch / 4
var sauter = toptouch / 13

var plus = avancer
if (witdttouch < 20) {
    witdttouch - 5
    toptouch - 5
}

//-----------------------------------------------------INITIALISATION GLOBALE/MENU JEU ---------------------------------------------------
//___________COMMENCER LE JEU ________________
async function commencer() {
    dead.pause();
    outgamesound.pause();
    document.getElementById('timer').style.zIndex = "2"
    document.getElementById('timer').style.fontSize = "1vw"
    document.getElementById('timer').style.left = "50vw"
    document.getElementById('Score').style.zIndex = "2"
    document.getElementById('Score').style.fontSize = "1vw"
    document.getElementById("pause").style.display = "none"
    document.getElementById("gris").style.display = "none";
    imgsol.src = img + "map1.png";
    imgPersonnage.src = img + "personnage1.png";
    imgarme.src = img + "arme1.png";
    imgbouclier.src = img + "bouclier1.png";
    imgbuissonG.src = img + "buisson1.png";
    imgbuissonD.src = img + "buisson2.png";
    imgciel.src = img + "ciel1.png";
    document.getElementById("menu").style.padding = "10%"
    document.getElementById("menu").style.margin = ""

    await delay(10);
    document.getElementById("menu").style.padding = "15%"
    document.getElementById("menu").style.margin = ""
    await delay(10);
    document.getElementById("menu").style.padding = "20%"
    document.getElementById("menu").style.margin = ""
    document.getElementById("menu").style.display = "none"
    document.getElementById("menu").style.margin = ""
    document.getElementById("menu").style.padding = "8% 5% 8% 5%"
    document.getElementById("Lejeux").style.display = ""
    if (document.getElementById("personnage")) {
        $("#personnage").attr('src', img + "personnage1.png ");
    }
    letimer()
    menuopen = false
    i = 0
    premierefois = true
    menuglob = false
    sousmenu = false
    menuPrincipale = false
    mapbuild();
    if (!TUTORIEL) {
        joueur();
        aleatoirenemis()
    } 
    miseenpause = false
    perso1 = true;
    mechant = true
    nombredemechantcontant = 0
    relancetime()
    if (!premierefoisjeux) {
        if (document.getElementById("personnage")) {
            document.getElementById("personnage").style.left = "10vw";
        }
        if (document.getElementById("arme")) {
            document.getElementById("arme").style.left = "10.5vw";
        }
        let n = 0;
        while (n < nombredemechanttotal) {
            if (document.getElementById('mechant' + n) != null) {
                $('#mechant' + n).offset({ left: $('#buisson').offset().left })
                document.getElementById("mechant" + n).remove()
            }
            n++
        }
    }

    nombredemechanttotal = 0
    premierefoisjeux = false
    died = false
}
//___________QUITTER LE JEU ________________
function quit() {
    outgamesound.play();
    menuPrincipale = true
    menuopen = true
    document.getElementById("timer").style.display = "none";
    document.getElementById("Score").style.display = "none";
    document.getElementById("menu").style.display = "";
    document.getElementById("pause").style.display = "none"
    document.getElementById("gris").style.display = "none";
    document.getElementById("Lejeux").style.display = "none"
    document.getElementById("tutotexte").style.display = "none";
    menuopen = true
    i = 0
    miseenpause= false
    bouclier = false
    premierefois = true
    if (document.getElementById("personnage")) {
        $("#personnage").attr('src', img + "personnage1.png ");
        document.getElementById("arme").remove()
        document.getElementById("personnage").remove()
    }
    if (document.getElementById("bouclier")) {
        document.getElementById("bouclier").style.top = "";
        document.getElementById("bouclier").style.left = "";
        document.getElementById("bouclier").remove();
    }
    let n = 0;

    while (n < nombredemechanttotal) {
        if (document.getElementById('mechant' + n) != null) {
            document.getElementById("mechant" + n).remove()
        }

        n++
    }
    nombredemechanttotal = 0
    nombredemechantcontant = 0
    timesec = 0
    timermin = 0
    scrorefinaux = 0
    document.getElementById('Score').innerHTML = 0;
    document.getElementById('sec').innerHTML = 00;
    document.getElementById('min').innerHTML = 00;
   
}
//___________CONTINUER LE JEU ________________
function Continuer() {
    if (died) {
        quit()
        document.getElementById("pause").style.display = "none"
        document.getElementById("gris").style.display = "none";
        commencer()
        if (document.getElementById("personnage")) {
            $("#personnage").attr('src', img + "personnage1.png ");
        }
    } else {
        outgamesound.pause();
        if (!TUTORIEL) {
        ingamesound.play();
        }
        document.getElementById("pause").style.display = "none"
        document.getElementById("gris").style.display = "none";
        perso1 = true;
        menuglob = false
        mechant = true
        menuopen = false
        miseenpause = false
        relancetime()
        letimer()
    }

}
//___________MISE EN PAUSE ________________
function echap() {
    premierefois = true
    if (!menuopen) {

        if (died) {
            ingamesound.pause();
            dead.play();
            save()
            document.getElementById('titreps').innerHTML = "--DIED--"
            document.getElementById('timer').style.zIndex = "5"
            document.getElementById('timer').style.left = "43.5vw"
            document.getElementById('timer').style.fontSize = "6vw"
            document.getElementById('Score').style.zIndex = "5"
            document.getElementById('Score').style.fontSize = "6vw"
            died = false
        } else {
            if (!TUTORIEL) {
                outgamesound.play();
                ingamesound.pause();
            } 
             document.getElementById('titreps').innerHTML = "-PAUSE-"
        }
        document.getElementById("pause").style.display = ""
        document.getElementById("gris").style.display = "block"
        menuglob = true;
        perso1 = false;
        mechant = false
        miseenpause = true
        stoptime()
        pausetimer()
        
    } else {
        menuPrincipale = true
        if (sousmenu) {
            document.getElementById("Setting").style.display = "none";
            document.getElementById("Mondes").style.display = "none";
            document.getElementById("touches").style.display = "none";
        }
        menusetting = false
        menuMonde = false
        menuTouche = false
        sousmenu = false
        document.getElementById("menu").style.display = "";
        menuglob = true;
    }
    
}
function setting() {
    menuPrincipale = false
    sousmenu = true
    document.getElementById("menu").style.display = "none"
    document.getElementById("Setting").style.display = ""
}
function TOUCHE(n) {
    switch (n) {
        case 0:
            document.getElementById("Setting").style.display = "none"
            document.getElementById("menu").style.display = "none"
            document.getElementById("touches").style.display = ""
            break;
        case 1:
            TOUCHE1 = true
            TOUCHE2 = false
            TOUCHE3 = false
            TOUCHE4 = false
            break;
        case 2:
            TOUCHE2 = true
            TOUCHE1 = false
            TOUCHE3 = false
            TOUCHE4 = false
            break;
        case 3:
            TOUCHE3 = true
            TOUCHE1 = false
            TOUCHE2 = false
            TOUCHE4 = false
            break;
        case 4:
            TOUCHE4 = true
            TOUCHE1 = false
            TOUCHE3 = false
            TOUCHE2 = false
            break;

    }
}

function MONDE() {
    document.getElementById("Setting").style.display = "none"
    document.getElementById("menu").style.display = "none"
    document.getElementById("Mondes").style.display = ""
    design.id = "designperso";
    document.body.appendChild(design);
    document.getElementById("Design").appendChild(design);
}
function precedentM() {
    navig.play();
    choix -= 1
    if (choix == 0) {
        choix = 3
        navig2.play();
    }
    document.getElementById('designperso').src = "img/design" + choix + "/personnage1.png"
    img = "img/design" + choix + "/"
}
function suivantM() {
    navig.play();
    choix += 1
    if (choix == 4) {
        navig3.play();
        choix = 1
    }
    document.getElementById('designperso').src = "img/design" + choix + "/personnage1.png"
    img = "img/design" + choix + "/"
}
//-----------------------------------------------------TIMER/DELAY---------------------------------------------------
//___________G�n�ration D'UN DELAY ________________
function delay(time) {
    return new Promise(resolve => setTimeout(resolve, time));
}
//___________DELAY MORT ENEMIS ________________
async function remise() {
    await delay(250);
    plus = avancer
}
//___________DELAY ATTACK ________________
async function attaqueready() {
    await delay(500);
    attaque = true
}
//___________INITIALISATION TIMER ET SCORE ________________
function letimer() {
    timer = setInterval(setTime, 100);
}
function setTime() {
    if (timesec <= 8) {
        var avecse = "0"
    } else {
        var avecse = ""
    }
    document.getElementById('Score').innerHTML = scrorefinaux;
    timesec += 1
    document.getElementById('sec').innerHTML = avecse + timesec;
    if (timesec >= 59) {
        timermin += 1
        if (timermin <= 9) {
            var avec = "0"
        } else {
            var avec = ""
        }
        document.getElementById('min').innerHTML = avec + timermin;
        timesec = 00
    }
    if (!TUTORIEL) {
        if (timermin % 3 == 0) {
        bouclieritem()
        }
        if (timermin % 2 == 0 & timermin != oldtimer) {
            difficulte = difficulte - (difficulte / 50)
            oldtimer = timermin
        }
        aleatoirenemis()
    }
   
}

//___________COUPE LES BOUCLES ________________
function pausetimer() {
    clearInterval(timer);
    timer = null;
}
function stoptime() {
    clearInterval(mouvementenemie);
    mouvementenemie = null;
    clearInterval(aleaenemi);
    aleaenemi = null;
}
function relancetime() {
    if (!mouvementenemie) {
        mouvementenemie = setInterval(mouvmechant, 60);
    }
}


//-----------------------------------------------------LES ELEMENTS G�n�r�s---------------------------------------------------

function joueur() {
    //----------------Perso1-------------------
    imgPersonnage.id = "personnage";
    document.body.appendChild(imgPersonnage);
    document.getElementById("lignepersonnage").appendChild(imgPersonnage);
    //----------------ARME-------------------
    imgarme.id = "arme";
    document.body.appendChild(imgarme);
    document.getElementById("lignepersonnage").appendChild(imgarme);
}
function mapbuild() {
    if (!TUTORIEL) {
    ingamesound = null
    ingamesound = new Audio("./sound/ingame.mp3")    
    ingamesound.play(); }
    //----------------Sol-------------------
    imgsol.id = "map";
    document.body.appendChild(imgsol);
    document.getElementById("lesol").appendChild(imgsol);
    //----------------FinSol-------------------

    document.getElementById("timer").style.display = "";
    document.getElementById("Score").style.display = "";
    document.getElementById("buisson").appendChild
    //----------------Buisson-------------------
    imgbuissonG.id = "buissongaucheimg";
    document.body.appendChild(imgbuissonG);
    document.getElementById("buissongauche").appendChild(imgbuissonG);
    imgbuissonD.id = "buissondroiteimg";
    document.body.appendChild(imgbuissonD);
    document.getElementById("buisson").appendChild(imgbuissonD);
    //----------------FinBuisson-------------------   
    imgciel.id = "ciel";
    document.body.appendChild(imgciel);
    document.getElementById("leciel").appendChild(imgciel);
    map = true;
    perso1 = true;
    mechant = true;
}
//-----------------------------------------------------LES MOUVEMENTS ENEMIS---------------------------------------------------
async function mouvmechant() {
    while (nombredemechantcontant < nombredemechanttotal) {
        var imgmechant = document.createElement("img");
        imgmechant.src = img + "mechant1.png";
        //----------------Mechant1-------------------
        imgmechant.id = "mechant" + nombredemechantcontant;
        document.body.appendChild(imgmechant);
        document.getElementById("lignemechant").appendChild(imgmechant);
        document.getElementById("mechant" + nombredemechantcontant).style.position = "absolute"
        document.getElementById("mechant" + nombredemechantcontant).style.width = "2.2vw"
        //----------------FinMechant1-------------------
        nombredemechantcontant++
    }
    if (nombredemechantcontant > nombredemechanttotal) {
        asupp = true
    }
    var n = 0;
    while (n < nombredemechantcontant) {
        if (document.getElementById('mechant' + n) != null) {
            if (!died) {
                if (perso1 && mechant) {
                    if (document.getElementById('mechant' + n) != null && $('#mechant' + n).offset().left < $('#buissongauche').offset().left) {
                        scrorefinaux += 50
                        if (asupp) {
                            document.getElementById("mechant" + n).remove()
                            asupp = false
                            nombredemechanttotal += 1
                        }
                        else { $('#mechant' + n).offset({ left: $('#buisson').offset().left }) }

                    } else if (document.getElementById('mechant' + n) != null && $('#mechant' + n).offset().left + witdttouch >= $('#personnage').offset().left && $('#mechant' + n).offset().top - toptouch <= $('#personnage').offset().top && $('#mechant' + n).offset().left - witdttouch <= $('#personnage').offset().left && $('#mechant' + n).offset().top + toptouch >= $('#personnage').offset().top) {
                        died = true
                        stoptime();
                        await delay(300);
                        if (TUTORIEL) {
                            commencer()
                            niv2 = true
                        } else {
                            echap()
                        }
                        document.getElementById("lignepersonnage").firstChild.src = img + "personnage1.png ";
                    } else if (document.getElementById('mechant' + n) != null && (!attaque && $('#mechant' + n).offset().left + witdttouch >= $('#arme').offset().left && $('#mechant' + n).offset().top - toptouch <= $('#arme').offset().top && $('#mechant' + n).offset().left - witdttouch <= $('#arme').offset().left && $('#mechant' + n).offset().top + toptouch >= $('#arme').offset().top)) {
                        document.getElementById("mechant" + n).remove()
                        scrorefinaux += 100
                        plus = plus / plus
                        if (TUTORIEL) {
                            niv3 = false
                            nombredemechanttotal -= 1
                        }
                        remise()
                    }
                    if (document.getElementById('mechant' + n) != null && bouclier && document.getElementById('bouclier') && ($('#mechant' + n).offset().left + (witdttouch - plus) >= $('#bouclier').offset().left && $('#mechant' + n).offset().top - toptouch <= $('#bouclier').offset().top && $('#mechant' + n).offset().left - (witdttouch - plus) <= $('#bouclier').offset().left && $('#mechant' + n).offset().top + toptouch >= $('#bouclier').offset().top)) {
                        document.getElementById("mechant" + n).remove()
                        scrorefinaux += 100
                        plus = plus / plus
                        boucliercoup.play()
                        remise()
                        brockbouclier()
                    }

                } $('#mechant' + n).offset({ left: $('#mechant' + n).offset().left - plus })
                Mouvement(n)
                await delay(300);
            }

        }
        if (n == 0) { deplacement++ }
        if (deplacement >= 6) deplacement = 0;
        n++
    }
}
//-----------------------------------------------------LES IMAGES PART SECONDES---------------------------------------------------
async function Mouvement(n) {
    $("#mechant" + n).attr('src', img + "mechant" + nl[deplacement] + ".png ");
    await delay(500);

}
async function Mouvementperso() {
    document.getElementById("lignepersonnage").firstChild.src = img + "personnage" + nl[deplacementpers] + ".png ";
    deplacementpers++
    if (deplacementpers >= 6) deplacementpers = 0;
}

//-----------------------------------------------------ITEMS DU JEU---------------------------------------------------

async function brockbouclier() {
    bouclierutilisation += 1
    if (bouclierutilisation == 5) {
        bouclier = false
        document.getElementById("bouclier").remove()
        if (TUTORIEL) {
            document.getElementById("tutotexte").style.display = "none";
            await delay(1000)
            document.getElementById("tutotexte").style.display = "";
            document.getElementById('Letexte').innerHTML = "Que la partie commence!!!!!!!!!!"
            await delay(1000)
            document.getElementById("tutotexte").style.display = "none";
            TUTORIEL = false
            niv1 = false
            niv2 = false
            niv3 = false
            niv4 = false
            stoptime()
            pausetimer()
            commencer()
        }
    }
}
function bouclieritem() {
    if (!document.getElementById("bouclier") && !menuopen) {
        imgbouclier.id = "bouclier";
        document.body.appendChild(imgbouclier);
        console.log($('#buisson').offset().left - (avancer * 10))
        document.getElementById("lignepersonnage").appendChild(imgbouclier);
        var alea = Math.floor(Math.random() * ($('#buisson').offset().left - (avancer * 20)) + $('#buissongauche').offset().left + (avancer * 10));
        $('#bouclier').offset({ left: alea, top: $('#bouclier').offset().top + plus })
        bouclierutilisation = 0
    }
}
//------------------------------------------------------------------------MOD ALEATOIRE----------------------------------------------
async function aleatoirenemis() {
    var alea = Math.floor(((Math.random() * difficulte) + 1));
    if (alea == 5) {
        nombredemechanttotal += 1
    }
}
//------------------------------------------------------------------------TUTORIEL----------------------------------------------
async function TUTO() {
    niv1 = true
    niv2 = true
    niv3 = true
    niv4 = true
    TUTORIEL = true
    commencer()
    await delay(500);
    document.getElementById("tutotexte").style.display = "";
    document.getElementById('Letexte').innerHTML = "Bien le bonjour a toi <br/> Press R pour Continuer"
}
//------------------------------------------------------------------------SAVE SCORE----------------------------------------------
function save() {
    if (saut == 1) {
        if (key == z) {
            saut == 2
        }
    }
    if (saut == 1) {
        delay(1000)
        saut=0
    }
    while (n < 10) {
        if (key == z) {
            saut == 2
        }
    }
}
