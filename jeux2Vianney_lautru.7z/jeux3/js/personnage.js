async function mouvsouris() {
    while (stop) {
        document.getElementById("vie").style.width = jaugevie + "%"
        document.getElementById("vie").style.marginLeft = 100 - jaugevie + "%"
        document.getElementById("jaugegemme").style.width = jaugegemme + "%"
        document.getElementById("jaugegemme").style.marginRight = 100 - jaugegemme + "%"
        if (jaugevie <= 0) {
            Mort()
            stop = false
            affichestate()
        }
        if (jaugegemme >= 100) {
            jaugegemme = 0
            amelioration()
            tiragecompt()
            stopTous()
            stop = false
        }
        taillehauteuroratk = idoratk.clientHeight
        taillehorizontaloratk = idoratk.clientWidth
        centreorakheight = taillehauteuroratk / 2
        centreorakwidht = taillehorizontaloratk / 2
        leftMap = $('#Map').offset().left
        topMap = $('#Map').offset().top
        Maptraidroite = taillehorizontalMap + leftMap
        Maptraigauche = leftMap
        Maptraihaut = topMap
        Maptraibas = taillehauteurMap + topMap
        MapCentreLargeur= Maptraidroite - (taillehorizontalMap/2)
        MapCentreHauteur= Maptraibas - (taillehauteurMap/2)

        leftoratk = $('#oratk').offset().left
        toporatk = $('#oratk').offset().top
        oratktraidroite = taillehorizontaloratk + leftoratk
        oratktraigauche = leftoratk
        oratktraihaut = toporatk
        oratktraibas = taillehauteuroratk + toporatk

        leftpersonnage = $('#personnage').offset().left
        toppersonnage = $('#personnage').offset().top
        personnagetraidroite = taillehorizontalpersonnage + leftpersonnage
        personnagetraigauche = leftpersonnage
        personnagetraihaut = toppersonnage
        personnagetraibas = taillehauteurpersonnage + toppersonnage

        centreperosnnageheight = taillehauteurpersonnage / 2
        centreperosnnagewidht = taillehorizontalpersonnage / 2
        centresouripersoheight = centreperosnnageheight + toppersonnage 
        centresouripersowidth = centreperosnnagewidht + leftpersonnage
        await delay(1);
        if (!(personnagetraigauche <= sourisX && personnagetraidroite >= sourisX && personnagetraibas > sourisY && personnagetraihaut < sourisY || personnagetraigauche <= sourisX && personnagetraidroite >= sourisX && personnagetraibas > sourisY && personnagetraihaut < sourisY)) {
            marche = true
            $('#oratk').offset({ left: leftpersonnage + centreperosnnagewidht - centreorakwidht, top: toppersonnage + centreperosnnageheight - centreorakheight })
            if (centresouripersowidth < sourisX) {
                $('#personnage').offset({ left: leftpersonnage + 3 })
                idperso.style.transform = 'rotateY(180deg)';
            }
            else if (centresouripersowidth > sourisX) {
                $('#personnage').offset({ left: leftpersonnage - 3 })
                idperso.style.transform = 'rotateY(0deg)';
        }
            if (centresouripersoheight < sourisY)
                $('#personnage').offset({ top: toppersonnage + 3 })
            else if (centresouripersoheight > sourisY)
                $('#personnage').offset({ top: toppersonnage - 3 })
        }

        if (personnagetraigauche >= Maptraigauche && personnagetraidroite <= Maptraidroite && personnagetraibas <= Maptraibas && personnagetraihaut >= Maptraihaut) {
            mouvmap()
        } else {
            if (personnagetraigauche <= Maptraigauche) {
                $('#personnage').offset({ left: leftpersonnage + 3 })
            } else if (personnagetraidroite >= Maptraidroite) {
                $('#personnage').offset({ left: leftpersonnage - 3 })
            } else if (personnagetraibas >= Maptraibas) {
                $('#personnage').offset({ top: toppersonnage - 3 })
            } else if (personnagetraihaut <= Maptraihaut) {
                $('#personnage').offset({ top: toppersonnage + 3 })
            }
        }

    }
}
async function tousnoire() {

    var imgmap = document.createElement("img");
    imgmap.src = "./img/map2light.png";
    imgmap.id = "map";
    document.body.appendChild(imgmap);
    document.getElementById("bosszone").appendChild(imgmap);
    var positionlampleft = centreperosnnagewidht - espacelumiereperso / 2
    var positionlamptop =  centreperosnnageheight - espacelumiereperso / 2
    taillehauteurflout = document.getElementById("map").clientHeight
    taillehorizontalflout = document.getElementById("map").clientWidth
    centrefloutheight = taillehauteurflout / 2
    centrefloutwidht = taillehorizontalflout / 2
    document.getElementById("Map").style.background="black"
    corbeau = true
    while (stop) {
      
        await delay(1);
        if (personnagetraigauche >= Maptraigauche && personnagetraidroite <= Maptraidroite && personnagetraibas <= Maptraibas && personnagetraihaut >= Maptraihaut) {

            if (leftpersonnage < leftleft) {
                if (Maptraigauche < 0)
                    positionlampleft -= 2
            } else if (leftpersonnage > leftright) {
                if (Maptraidroite > fenetrewidth)
                    positionlampleft += 2
            }
            if (toppersonnage < Topup) {
                if (Maptraihaut < 0)
                    positionlamptop -= 2

            } else if (toppersonnage > Topdown) {
                if (Maptraibas > fenetreheight)
                    positionlamptop += 2
            }
        } else {
            positionlampleft = centreperosnnagewidht - espacelumiereperso / 2
            positionlamptop = centreperosnnageheight - espacelumiereperso / 2
        }
        $('#map').offset({ left: centreperosnnagewidht - espacelumiereperso / 2, top: centreperosnnageheight - espacelumiereperso / 2 })

        document.getElementById("map").style.paddingTop = (-positionlamptop) + "px"
        document.getElementById("map").style.paddingLeft = (-positionlampleft) + "px"
        document.getElementById("map").style.clip = "rect(" + toppersonnage + "px, " + (espacelumiereperso + leftpersonnage) + "px, " + (espacelumiereperso + toppersonnage) + "px, " + leftpersonnage + "px)";

    }
}