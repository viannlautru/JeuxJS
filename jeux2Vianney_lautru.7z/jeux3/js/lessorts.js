var artificetraigauche
var firstartifice = true
var nombredeartificecontant = 0
var nombredeartificetotal = 0
let artifice = []
let artificetop = []
let artificeleft = []
let exploartifice = []
let numgemme = []
let etatgemme = []
let delaygemme = []
let degatbouclier = []

var laseron = true
var gemmeplus = 0

var orakcharge = ""
var taillehorizontallaser

async function rotategemme() {
    for (var gr in etatgemme) {
        if (document.getElementById('ressource' + gr)) {
            await delay(100);
            $("#ressource" + gr).attr('src', "./img/ressource" + etatgemme[gr] + ".png ");
            etatgemme[gr] += 1
            if (etatgemme[gr] == 4) etatgemme[gr] = 0
        }
    }
}

async function attaqueprete() {
    if (autoattaque) {
        orakcharge = "charge"
    }
    else orakcharge = ""
}

async function rotateorak() {
    while (stop) {
        await delay(100);
        $("#oratk").attr('src', "./img/Orattack" + o + orakcharge + ".png ");
        await delay(100);
        o += 1
        if (o > 2) {
            o = 0
        }
    }
}
function autotape() {
    autoattaque = true
}
async function creatartifice() {
    if ((mechant1.length > 0)) {
        while (nombredeartificecontant < nombredeartificetotal) {
            var imgartifice = document.createElement("img");
            imgartifice.src = "./img/artifice.png";
            imgartifice.id = "artifice" + nombredeartificecontant;
            document.getElementById("Personnage").appendChild(imgartifice);
            document.getElementById("artifice" + nombredeartificecontant).className = "artifice"
            aleamechant = Math.floor(((Math.random() * mechant1.length) + 0))
            const angle = Math.atan2(
                ($('#' + mechant1[aleamechant]).offset().top + taillehauteurmechant/ 2) - (centreperosnnageheight + toppersonnage),
                ($('#' + mechant1[aleamechant]).offset().left + taillehorizontalmechant/2) - (centreperosnnagewidht + leftpersonnage)
            )
            cibleleft= Math.cos(angle)
            cibletop = Math.sin(angle)
            artifice.push('artifice' + nombredeartificecontant)
            artificetop.push(cibletop)
            artificeleft.push(cibleleft)

            $('#artifice' + nombredeartificecontant).offset({ left: -100, top: -100 })

            if (firstartifice) {
                idartifice = document.getElementById('artifice' + nombredeartificecontant)
                taillehauteurartifice = idartifice.clientHeight
                taillehorizontalartifice = idartifice.clientWidth
                firstartifice = false
            }
            $("#artifice" + nombredeartificecontant).offset({ left: leftpersonnage + centreperosnnagewidht - taillehorizontalartifice , top: toppersonnage + centreperosnnageheight - taillehauteurartifice})

            nombredeartificecontant++

        }
        if (nombredeartificecontant > nombredeartificetotal) {
            asupp = true
        }
    }
}

async function attaartificedelayfun() {
    while (stop) {
        lancementartifice = true
        nombredeartificetotal += nombrefuser
        await delay(delayfuser)
    }
}
function artificefeu() {
    if ((mechant1.length > 0)) {
        if (nombredeartificecontant < nombredeartificetotal) {
            creatartifice()
        }
        for (var a1 in artifice) {
            if ($("#" + artifice[a1]).offset().left >= Maptraigauche && $("#" + artifice[a1]).offset().left + taillehorizontalartifice <= Maptraidroite && $("#" + artifice[a1]).offset().top + taillehauteurartifice <= Maptraibas && $("#" + artifice[a1]).offset().top >= Maptraihaut) {
                if (artificeleft[a1] > 0) document.getElementById(artifice[a1]).style.transform = "rotateY(0deg)"
                else document.getElementById(artifice[a1]).style.transform = "rotateY(180deg)"
                $('#' + artifice[a1]).offset({ left: $('#' + artifice[a1]).offset().left + artificeleft[a1], top: $('#' + artifice[a1]).offset().top + artificetop[a1] })
            } else {
                etatexplosion.push(0)
                exploartifice.push(artifice[a1])
                if (artifice.indexOf(artifice[a1]) !== -1) {
                    artifice.splice(artifice.indexOf(artifice[a1]), 1);
                    artificeleft.splice(artificeleft.indexOf(artificeleft[a1]), 1);
                    artificetop.splice(artificetop.indexOf(artificetop[a1]), 1);
                }
            }
        }
    }
}
async function lelaser() {
    while (stop) {
            if (firstlaser) {
                firstlaser = false
                var imglaserhorizon = document.createElement("img");
                imglaserhorizon.src = "./img/laser.png";
                imglaserhorizon.id = "laserhorizon";
                document.getElementById("Personnage").appendChild(imglaserhorizon);
                document.getElementById("laserhorizon").className = "laser"

                var imglaservertical = document.createElement("img");
                imglaservertical.src = "./img/laser.png";
                imglaservertical.id = "laservertical";
                document.getElementById("Personnage").appendChild(imglaservertical);
                document.getElementById("laservertical").className = "laser"

                var imglaserdiagD = document.createElement("img");
                imglaserdiagD.src = "./img/diagonal.png";
                imglaserdiagD.id = "laserlaserdiagD";
                document.getElementById("Personnage").appendChild(imglaserdiagD);
                document.getElementById("laserlaserdiagD").className = "laserdiag"
                idlaserdiag = document.getElementById("laserlaserdiagD")

                var imglaserdiagG = document.createElement("img");
                imglaserdiagG.src = "./img/diagonal.png";
                imglaserdiagG.id = "laserlaserdiagG";
                document.getElementById("Personnage").appendChild(imglaserdiagG);
                document.getElementById("laserlaserdiagG").className = "laserdiag"
                idlaserdiag = document.getElementById("laserlaserdiagG")

                taillehauteurlaserdiag = idlaserdiag.clientHeight
                taillehorizontallaserdiag = idlaserdiag.clientWidth
                centrelaserdiagheight = taillehauteurlaserdiag / 2
                centrelaserdiagwidht = taillehorizontallaserdiag / 2

                idlaser = document.getElementById("laservertical")
                taillehauteurlaser = idlaser.clientHeight
                taillehorizontallaser = idlaser.clientWidth
                centrelaserheight = taillehauteurlaser / 2
                centrelaserwidht = taillehorizontallaser / 2

                document.getElementById("laserhorizon").style.display = "none"
                document.getElementById("laservertical").style.display = "none"
                document.getElementById("laserlaserdiagD").style.display = "none"
                document.getElementById("laserlaserdiagG").style.display = "none"

            }

        if (laseron) {
            
            document.getElementById("laservertical").style.display = ""
            if (niv2laser)document.getElementById("laserhorizon").style.display = ""
            if (niv3laser)document.getElementById("laserlaserdiagD").style.display = ""
            if (niv4laser)document.getElementById("laserlaserdiagG").style.display = ""
            $('#laserhorizon').offset({ left: leftpersonnage + centreperosnnagewidht - centrelaserwidht, top: toppersonnage + centreperosnnageheight - centrelaserheight })
            $('#laservertical').offset({ left: leftpersonnage + centreperosnnagewidht, top: (toppersonnage + centreperosnnageheight - centrelaserwidht) })
            $('#laserlaserdiagD').offset({ left: leftpersonnage + centreperosnnagewidht - centrelaserdiagwidht, top: toppersonnage + centreperosnnageheight - centrelaserdiagheight })
            $('#laserlaserdiagG').offset({ left: leftpersonnage + centreperosnnagewidht - centrelaserdiagwidht, top: toppersonnage + centreperosnnageheight - centrelaserdiagheight })

            document.getElementById("laservertical").style.transform = "rotate(90deg)"
            document.getElementById("laserlaserdiagG").style.transform = "rotateY(180deg)"
   
            for (var n1 in mechant1) {
                laserActive= true 
                const anglelaser = Math.atan2(
                    ($('#' + mechant1[n1]).offset().top + taillehauteurmechant / 2) - (centreperosnnageheight + toppersonnage),
                    ($('#' + mechant1[n1]).offset().left + taillehorizontalmechant / 2) - (centreperosnnagewidht + leftpersonnage)
                )
                cibleleft = Math.cos(anglelaser)
                cibletop = Math.sin(anglelaser)

                if (leftpersonnage + (taillehorizontalpersonnage / 2) >= $('#' + mechant1[n1]).offset().left && leftpersonnage + (taillehorizontalpersonnage / 2) <= $('#' + mechant1[n1]).offset().left + taillehorizontalmechant) {
                    viemechant1[n1] -= DegatLaser
                }
                if (niv2laser) {
                    if (toppersonnage + (taillehauteurpersonnage / 2) >= $('#' + mechant1[n1]).offset().top && toppersonnage + (taillehauteurpersonnage / 2) <= $('#' + mechant1[n1]).offset().top + taillehauteurmechant) {
                        viemechant1[n1] -= DegatLaser
                    }
                }
                if (niv3laser) {
                    if (cibleleft < 0.8 && cibleleft > 0.6 && cibletop > -0.8 && cibletop < -0.6 || cibleleft > -0.8 && cibleleft < -0.6 && cibletop < 0.8 && cibletop > 0.6) {
                        viemechant1[n1] -= DegatLaser
                    }
                }
                if (niv4laser) {
                    if (cibleleft < 0.8 && cibleleft > 0.6 && cibletop < 0.8 && cibletop > 0.6 || cibleleft > -0.8 && cibleleft < -0.6 && cibletop > -0.8 && cibletop < -0.6) {
                        viemechant1[n1] -= DegatLaser
                    }
                }
            }
        }
        await delay(1000)
        laseron = false
        document.getElementById("laserhorizon").style.display = "none"
        document.getElementById("laservertical").style.display = "none"
        document.getElementById("laserlaserdiagD").style.display = "none"
        document.getElementById("laserlaserdiagG").style.display = "none"
        await delay(delaylaserattaque)
        laseron = true
    }
}
async function Bouclier() {
    var imgbouclier = document.createElement("img");
    imgbouclier.src = "./img/bouclier1.png";
    imgbouclier.id = "bouclier";
    document.body.appendChild(imgbouclier);
    document.getElementById("Personnage").appendChild(imgbouclier);
    idbouclier = document.getElementById("bouclier")
    taillehauteurbouclier = idbouclier.clientHeight
    taillehorizontalbouclier = idbouclier.clientWidth
    centrebouclierheight = taillehauteurbouclier / 2
    centrebouclierwidht = taillehorizontalbouclier / 2
    while (stop) {
        bouclierActive = true
        var total =0
        document.getElementById("bouclier").style.display = ""
        boucliertime =true
        await delay(10)
        $('#bouclier').offset({ left: leftpersonnage + centreperosnnagewidht - centrebouclierwidht, top: toppersonnage + centreperosnnageheight - centrebouclierheight })
        for (var vb in degatbouclier) {
            total += degatbouclier[vb]
        }
            if( total < viebouclier / 5)
                $("#bouclier").attr('src', "./img/bouclier1.png ");
            else if (total > viebouclier / 5 && total < (viebouclier / 5) * 2)
                $("#bouclier").attr('src', "./img/bouclier2.png ");
            else if ( (total > viebouclier / 5) * 2 && total < (viebouclier / 5) * 3)
                $("#bouclier").attr('src', "./img/bouclier3.png ");
            else if ( (total > viebouclier / 5) * 4)
                $("#bouclier").attr('src', "./img/bouclier4.png ");
        if (total >= viebouclier) {
            boucliertime = false
            document.getElementById("bouclier").style.display = "none"
            degatbouclier=[]
        }
        if (!boucliertime) {
            await delay(delayraparitionblouclier)
        }
    }
}