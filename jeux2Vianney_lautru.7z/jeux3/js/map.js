async function mouvmap() {
    leftmap = $('#Map').offset().left
    topmap = $('#Map').offset().top
    leftpersonnage = $('#personnage').offset().left
    toppersonnage = $('#personnage').offset().top
    await delay(1);

    if (leftpersonnage < leftleft) {
        if (Maptraigauche < 0)
            $('#Map').offset({ left: leftmap + 2 })
    } else if (leftpersonnage > leftright) {
        if (Maptraidroite > fenetrewidth)
            $('#Map').offset({ left: leftmap - 2 })
    }
    if (toppersonnage < Topup) {
        if (Maptraihaut < 0)
            $('#Map').offset({ top: topmap + 2 })

    } else if (toppersonnage > Topdown) {
        if (Maptraibas > fenetreheight)
            $('#Map').offset({ top: topmap - 2 })
    }
}