
let mouvementenemieok
let mortenemie
let creaenemieok

let autoattacke
let laserattacke
let rotationgemme
let collision
let attaqueready
let attaartificedelay
let explosion 
let collisiongemme
let boucliertime
let collisionfusee
var h1 = document.getElementsByTagName('h1')[0];
var sec = 0;
var sec2 = 0
var min = 0;
var hrs = 0;
var timers;

function tick() {
    sec++;
    if (!bossactive) sec2++
    else sec2=0
    if (sec >= 60) {
        sec = 0;
        sec2 = 0;
        min++;
        if (min >= 60) {
            min = 0;
            hrs++;
        }
    }
}
function add() {
    tick();
    document.getElementById("temps").textContent = (hrs > 9 ? hrs : "0" + hrs)
        + ":" + (min > 9 ? min : "0" + min)
        + ":" + (sec > 9 ? sec : "0" + sec);
    lancetimer();
}
function lancetimer() {
    timers = setTimeout(add, 1000);
}
function stoptimer() {
    clearInterval(timers);
    timers = null;
}
function jeuxLibre() {
    lanceTous()
    lanceLibre()
}
function Tutojeux() {
    lanceTous()
    tuto()
}
function modeHistoire() {
    lanceTous()
    modeaventure()
}
function stopTous() {
    stopmechant()
    stopautoat()
    stoprotagemme()
    stopcollision()
    stopattaqueready()
    stoptimer()
}
function lanceTous() {
    lancemechant()
    lanceautotape()
    lancerotagemme()
    lancecollision()
    lanceattaqueready()
    lancetimer()
    rotateorak()
    mouvsouris()
    stop = true
  
}

function stoprotagemme() {
    clearInterval(rotationgemme);
    rotationgemme = null;
}

function lancerotagemme() {
    if (!rotationgemme) {
        rotationgemme = setInterval(rotategemme, 100);
    }
}
function stopautoat() {
    clearInterval(autoattacke);
    autoattacke = null;
    clearInterval(laserattacke);
    laserattacke = null;
}
function lanceautotape() {
    if (!autoattacke) {
        autoattacke = setInterval(autotape, delayautoattaque);
    }
}
function stopmechant() {
    clearInterval(mouvementenemieok);
    mouvementenemieok = null;
    clearInterval(mortenemie);
    mortenemie = null;
    clearInterval(creaenemieok);
    creaenemieok = null;
}
function lancemechant() {
        if (!creaenemieok) {
            creaenemieok = setInterval(creatmechant, 60);
        }
    if (!mouvementenemieok) {
        mouvementenemieok = setInterval(mouvmechant, 60);
        mortenemie = setInterval(mortmechant, 10);
    }
}
function stopcollision() {
    clearInterval(collision);
    collision = null;
    clearInterval(explosion);
    explosion = null;
    clearInterval(collisionfusee);
    collisionfusee = null;
    clearInterval(boucliertime);
    boucliertime = null;
}
function lancecollision() {
    if (!collision) {
        collision = setInterval(collisionmechant, 10);
        collisionfusee = setInterval(colisionfusee, 100);
        explosion = setInterval(colisionfuseeexplosion, 100);
        collisiongemme = setInterval(contactegemme, 100);
    }
}
function stopattaqueready() {
    clearInterval(attaqueready);
    attaqueready = null;
    clearInterval(attaartificedelay);
    attaartificedelay = null;
}
function lanceattaqueready() {
    attaartificedelay = setInterval(artificefeu, 10);
    if (!attaqueready) {
        attaqueready = setInterval(attaqueprete, 1);
    }
}
