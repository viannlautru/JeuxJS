var leftcorbeau 
var topcorbeau
var corbeautraidroite
var corbeautraigauche
var corbeautraihaut
var corbeautraibas


async function creatmechant() {
    while (nombredemechantcontant < nombredemechanttotal) {
        var imgmechant = document.createElement("img");
        designmechant = Math.floor(((Math.random() * 2) + 1))
        imgmechant.src = "./img/mechant" + designmechant +".png";
        //----------------Mechant1-------------------
        imgmechant.id = "mechant" + nombredemechantcontant;
        document.body.appendChild(imgmechant);
        document.getElementById("Personnage").appendChild(imgmechant);
        document.getElementById("mechant" + nombredemechantcontant).className = "mechant"
        mechant1.push('mechant' + nombredemechantcontant)
        viemechant1.push(VieMechant)

        $('#mechant' + nombredemechantcontant).offset({ left: retourleft(), top: retourtop() })
        //----------------FinMechant1-------------------
        if (firstmechant) {
            idmechant = document.getElementById('mechant' + nombredemechantcontant)
            taillehauteurmechant = idmechant.clientHeight
            taillehorizontalmechant = idmechant.clientWidth
            firstmechant = false
        }
        nombredemechantcontant++
    }
    if (nombredemechantcontant > nombredemechanttotal) {
        asupp = true
    }
}
function mouvmechant() {
    for (var n in mechant1) {
        if (document.getElementById(mechant1[n]) && $("#" + mechant1[n]).offset().left < leftpersonnage) {
            if (!($("#" + mechant1[n]).offset().left < leftpersonnage && $("#" + mechant1[n]).offset().left + taillehorizontalmechant > leftpersonnage)) {
            $("#" + mechant1[n]).offset({ left: $("#" + mechant1[n]).offset().left + 3 })
                document.getElementById(mechant1[n]).style.transform = 'rotateY(180deg)'
            }
        }
        else if (document.getElementById(mechant1[n]) && $("#" + mechant1[n]).offset().left + taillehorizontalmechant > leftpersonnage) {
            if (!($("#" + mechant1[n]).offset().left < leftpersonnage && $("#" + mechant1[n]).offset().left + taillehorizontalmechant > leftpersonnage)) {
            $("#" + mechant1[n]).offset({ left: $("#" + mechant1[n]).offset().left - 3 })
                    document.getElementById(mechant1[n]).style.transform = 'rotateY(0deg)'
            }
        }
        if (document.getElementById(mechant1[n]) && $("#" + mechant1[n]).offset().top < toppersonnage)
            $("#" + mechant1[n]).offset({ top: $("#" + mechant1[n]).offset().top + 3 })
        else if (document.getElementById(mechant1[n]) && $("#" + mechant1[n]).offset().top > toppersonnage)
            $("#" + mechant1[n]).offset({ top: $("#" + mechant1[n]).offset().top - 3 })
    }
}




function retourtop(){
    var alea = Math.floor(((Math.random() * 4) + 1));

    switch (alea) {
        case 1:
            var aleatop = Math.floor(((Math.random() * 0)));
            break;
        case 2:
            var aleatop = Math.floor(((Math.random() * taillehauteurMap)));
            break;
        case 3:
            var aleatop = Math.floor(((Math.random() * taillehauteurMap)));
            break;
        case 4:
            var aleatop = Math.floor(((Math.random() * (taillehorizontalMap - taillehorizontalMap)) + taillehorizontalMap));
            break;
    }
    return aleatop
}
function retourleft() {
    var alea = Math.floor(((Math.random() * 4) + 1));

    switch (alea) {
        case 1:
            var aleawidth = Math.floor(((Math.random() * taillehorizontalMap)));
            break;
        case 2:
            var aleawidth = Math.floor(((Math.random() * -0) + -10));
            break;
        case 3:
            var aleawidth = Math.floor(((Math.random() * (taillehauteurMap - taillehauteurMap - 10)) + taillehauteurMap - 10));
            break;
        case 4:
            var aleawidth = Math.floor(((Math.random() * taillehorizontalMap)));
            break;
    }
    return aleawidth
}
function letitans() {

}