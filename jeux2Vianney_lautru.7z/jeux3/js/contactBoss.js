function contactboule() {
    for (var bf in bouledefeu) {
        if (autoattaque && Etatboulle[bf] == 0 && document.getElementById(bouledefeu[bf]) && (oratktraigauche <= $('#' + bouledefeu[bf]).offset().left && oratktraidroite >= $('#' + bouledefeu[bf]).offset().left && oratktraibas > $('#' + bouledefeu[bf]).offset().top && oratktraihaut < taillehauteurbouledefeu + $('#' + bouledefeu[bf]).offset().top || oratktraigauche <= taillehorizontalbouledefeu + $('#' + bouledefeu[bf]).offset().left && oratktraidroite >= taillehorizontalbouledefeu + $('#' + bouledefeu[bf]).offset().left && oratktraibas > $('#' + bouledefeu[bf]).offset().top && oratktraihaut < taillehauteurbouledefeu + $('#' + bouledefeu[bf]).offset().top)) {
            Etatboulle[bf] = 1
            bouledefeutrace[bf] = "ligne"
            const angle = Math.atan2(
                ($('#titanfeu').offset().top + titanfeucentrehauteur) - (centreperosnnageheight + toppersonnage),
                ($('#titanfeu').offset().left + titanfeucentrelargeur) - (centreperosnnagewidht + leftpersonnage)
            )
            directiontop[bf] = (Math.sin(angle))
            directionleft[bf] = (Math.cos(angle))
        }
        if (document.getElementById(bouledefeu[bf]) && (personnagetraigauche <= $('#' + bouledefeu[bf]).offset().left && personnagetraidroite >= $('#' + bouledefeu[bf]).offset().left && personnagetraibas > $('#' + bouledefeu[bf]).offset().top && personnagetraihaut < taillehauteurbouledefeu + $('#' + bouledefeu[bf]).offset().top || personnagetraigauche <= taillehorizontalbouledefeu + $('#' + bouledefeu[bf]).offset().left && personnagetraidroite >= taillehorizontalbouledefeu + $('#' + bouledefeu[bf]).offset().left && personnagetraibas > $('#' + bouledefeu[bf]).offset().top && personnagetraihaut < taillehauteurbouledefeu + $('#' + bouledefeu[bf]).offset().top)) {
            jaugevie -= 1
            suppboulle(bf)
        }
    }
}
function contactbouletitan() {
    for (var bf in bouledefeu) {
        if (Etatboulle[bf] == 1 && document.getElementById(bouledefeu[bf]) && (titanfeutraigauche <= $('#' + bouledefeu[bf]).offset().left && titanfeutraidroite >= $('#' + bouledefeu[bf]).offset().left && titanfeutraibas > $('#' + bouledefeu[bf]).offset().top && titanfeutraihaut < taillehauteurbouledefeu + $('#' + bouledefeu[bf]).offset().top || titanfeutraigauche <= taillehorizontalbouledefeu + $('#' + bouledefeu[bf]).offset().left && titanfeutraidroite >= taillehorizontalbouledefeu + $('#' + bouledefeu[bf]).offset().left && titanfeutraibas > $('#' + bouledefeu[bf]).offset().top && titanfeutraihaut < taillehauteurbouledefeu + $('#' + bouledefeu[bf]).offset().top)) {
            vietitanfeu -= 50
            suppboulle(bf)
        }
    }
    if ((personnagetraigauche <= titanfeutraigauche && personnagetraidroite >= titanfeutraigauche && personnagetraibas > titanfeutraihaut && personnagetraihaut < titanfeutraibas || personnagetraigauche <= titanfeutraidroite && personnagetraidroite >= titanfeutraidroite && personnagetraibas > titanfeutraihaut && personnagetraihaut < titanfeutraibas)) {
        jaugevie -= 5
    }
}
function contactvaguefeu() {
    for (var vg in toutevaguefeu) {
        switch (directionvaguefeu[vg]) {
            case 'gauchehautdiag': case 'droitebasdiag': case 'droitehautdiag': case 'gauchebastdiag':
                const anglelaser = Math.atan2(
                    ($('#' + toutevaguefeu[vg]).offset().top + document.getElementById(toutevaguefeu[vg]).clientHeight / 2) - (centreperosnnageheight + toppersonnage),
                    ($('#' + toutevaguefeu[vg]).offset().left + document.getElementById(toutevaguefeu[vg]).clientWidth / 2) - (centreperosnnagewidht + leftpersonnage)
                )
                cibleleft = Math.cos(anglelaser)
                cibletop = Math.sin(anglelaser)
                switch (directionvaguefeu[vg]) {
                    case 'gauchehautdiag':
                        if (cibleleft > -0.9 && cibleleft < -0.2 && cibletop > -0.9 && cibletop < -0.2 || cibleleft < 0.9 && cibleleft > 0.2 && cibletop < 0.9 && cibletop > 0.2 ||cibleleft < 0.9 && cibleleft > 0.2 && cibletop > -0.9 && cibletop < -0.2 || cibleleft > -0.9 && cibleleft < -0.2 && cibletop < 0.9 && cibletop > 0.2 ) {
                            if (document.getElementById(toutevaguefeu[vg]) && ($('#' + toutevaguefeu[vg]).offset().left <= personnagetraigauche && document.getElementById(toutevaguefeu[vg]).clientWidth + $('#' + toutevaguefeu[vg]).offset().left >= personnagetraigauche && $('#' + toutevaguefeu[vg]).offset().top < personnagetraibas && document.getElementById(toutevaguefeu[vg]).clientHeight + $('#' + toutevaguefeu[vg]).offset().top > personnagetraihaut || document.getElementById(toutevaguefeu[vg]).clientWidth + $('#' + toutevaguefeu[vg]).offset().left >= personnagetraidroite && $('#' + toutevaguefeu[vg]).offset().left <= personnagetraidroite && $('#' + toutevaguefeu[vg]).offset().top < personnagetraibas && document.getElementById(toutevaguefeu[vg]).clientHeight + $('#' + toutevaguefeu[vg]).offset().top > personnagetraihaut)) {
                                jaugevie -= degatvagueflamme
                                $('#personnage').offset({ left: leftpersonnage - 20, top: toppersonnage - 20 })
                            }
                        }
                        break;
                    case 'droitebasdiag':
                        if (cibleleft > -0.9 && cibleleft < -0.2 && cibletop > -0.9 && cibletop < -0.2 || cibleleft < 0.9 && cibleleft > 0.2 && cibletop < 0.9 && cibletop > 0.2 || cibleleft < 0.9 && cibleleft > 0.2 && cibletop > -0.9 && cibletop < -0.2 || cibleleft > -0.9 && cibleleft < -0.2 && cibletop < 0.9 && cibletop > 0.2) {
                            if (document.getElementById(toutevaguefeu[vg]) && ($('#' + toutevaguefeu[vg]).offset().left <= personnagetraigauche && document.getElementById(toutevaguefeu[vg]).clientWidth + $('#' + toutevaguefeu[vg]).offset().left >= personnagetraigauche && $('#' + toutevaguefeu[vg]).offset().top < personnagetraibas && document.getElementById(toutevaguefeu[vg]).clientHeight + $('#' + toutevaguefeu[vg]).offset().top > personnagetraihaut || document.getElementById(toutevaguefeu[vg]).clientWidth + $('#' + toutevaguefeu[vg]).offset().left >= personnagetraidroite && $('#' + toutevaguefeu[vg]).offset().left <= personnagetraidroite && $('#' + toutevaguefeu[vg]).offset().top < personnagetraibas && document.getElementById(toutevaguefeu[vg]).clientHeight + $('#' + toutevaguefeu[vg]).offset().top > personnagetraihaut)) {
                                jaugevie -= degatvagueflamme
                                $('#personnage').offset({ left: leftpersonnage + 20, top: toppersonnage + 20 })
                            }
                        }
                        break;
                    case 'droitehautdiag':
                        if (cibleleft > -0.9 && cibleleft < -0.2 && cibletop > -0.9 && cibletop < -0.2 || cibleleft < 0.9 && cibleleft > 0.2 && cibletop < 0.9 && cibletop > 0.2 || cibleleft < 0.9 && cibleleft > 0.2 && cibletop > -0.9 && cibletop < -0.2 || cibleleft > -0.9 && cibleleft < -0.2 && cibletop < 0.9 && cibletop > 0.2) {
                            if (document.getElementById(toutevaguefeu[vg]) && ($('#' + toutevaguefeu[vg]).offset().left <= personnagetraigauche && document.getElementById(toutevaguefeu[vg]).clientWidth + $('#' + toutevaguefeu[vg]).offset().left >= personnagetraigauche && $('#' + toutevaguefeu[vg]).offset().top < personnagetraibas && document.getElementById(toutevaguefeu[vg]).clientHeight + $('#' + toutevaguefeu[vg]).offset().top > personnagetraihaut || document.getElementById(toutevaguefeu[vg]).clientWidth + $('#' + toutevaguefeu[vg]).offset().left >= personnagetraidroite && $('#' + toutevaguefeu[vg]).offset().left <= personnagetraidroite && $('#' + toutevaguefeu[vg]).offset().top < personnagetraibas && document.getElementById(toutevaguefeu[vg]).clientHeight + $('#' + toutevaguefeu[vg]).offset().top > personnagetraihaut)) {
                                jaugevie -= degatvagueflamme
                                $('#personnage').offset({ left: leftpersonnage + 20, top: toppersonnage - 20 })
                            }
                        }
                        break;
                    case 'gauchebastdiag':
                        if (cibleleft > -0.9 && cibleleft < -0.2 && cibletop > -0.9 && cibletop < -0.2 || cibleleft < 0.9 && cibleleft > 0.2 && cibletop < 0.9 && cibletop > 0.2 || cibleleft < 0.9 && cibleleft > 0.2 && cibletop > -0.9 && cibletop < -0.2 || cibleleft > -0.9 && cibleleft < -0.2 && cibletop < 0.9 && cibletop > 0.2) {
                            if (document.getElementById(toutevaguefeu[vg]) && ($('#' + toutevaguefeu[vg]).offset().left <= personnagetraigauche && document.getElementById(toutevaguefeu[vg]).clientWidth + $('#' + toutevaguefeu[vg]).offset().left >= personnagetraigauche && $('#' + toutevaguefeu[vg]).offset().top < personnagetraibas && document.getElementById(toutevaguefeu[vg]).clientHeight + $('#' + toutevaguefeu[vg]).offset().top > personnagetraihaut || document.getElementById(toutevaguefeu[vg]).clientWidth + $('#' + toutevaguefeu[vg]).offset().left >= personnagetraidroite && $('#' + toutevaguefeu[vg]).offset().left <= personnagetraidroite && $('#' + toutevaguefeu[vg]).offset().top < personnagetraibas && document.getElementById(toutevaguefeu[vg]).clientHeight + $('#' + toutevaguefeu[vg]).offset().top > personnagetraihaut)) {
                                jaugevie -= degatvagueflamme
                                $('#personnage').offset({ left: leftpersonnage - 20, top: toppersonnage + 20 })
                            }
                        }
                        break;
                }
                break;
                case 'haut':
                    if (document.getElementById(toutevaguefeu[vg]) && ($('#' + toutevaguefeu[vg]).offset().left <= personnagetraigauche && document.getElementById(toutevaguefeu[vg]).clientHeight + $('#' + toutevaguefeu[vg]).offset().left >= personnagetraigauche && $('#' + toutevaguefeu[vg]).offset().top < personnagetraibas && document.getElementById(toutevaguefeu[vg]).clientWidth + $('#' + toutevaguefeu[vg]).offset().top > personnagetraihaut || document.getElementById(toutevaguefeu[vg]).clientHeight + $('#' + toutevaguefeu[vg]).offset().left >= personnagetraidroite && $('#' + toutevaguefeu[vg]).offset().left <= personnagetraidroite && $('#' + toutevaguefeu[vg]).offset().top < personnagetraibas && document.getElementById(toutevaguefeu[vg]).clientWidth + $('#' + toutevaguefeu[vg]).offset().top > personnagetraihaut)) {
                    jaugevie -= degatvagueflamme
                        $('#personnage').offset({ top: toppersonnage - 20 })
                    }
                    break;
                case 'bas':
                if (document.getElementById(toutevaguefeu[vg]) && ($('#' + toutevaguefeu[vg]).offset().left <= personnagetraigauche && document.getElementById(toutevaguefeu[vg]).clientHeight + $('#' + toutevaguefeu[vg]).offset().left >= personnagetraigauche && $('#' + toutevaguefeu[vg]).offset().top < personnagetraibas && document.getElementById(toutevaguefeu[vg]).clientWidth + $('#' + toutevaguefeu[vg]).offset().top > personnagetraihaut || document.getElementById(toutevaguefeu[vg]).clientHeight + $('#' + toutevaguefeu[vg]).offset().left >= personnagetraidroite && $('#' + toutevaguefeu[vg]).offset().left <= personnagetraidroite && $('#' + toutevaguefeu[vg]).offset().top < personnagetraibas && document.getElementById(toutevaguefeu[vg]).clientWidth + $('#' + toutevaguefeu[vg]).offset().top > personnagetraihaut)) {
                        jaugevie -= degatvagueflamme
                        $('#personnage').offset({ top: toppersonnage + 20 })
                    }
                    break;
                case 'gauche':
                if (document.getElementById(toutevaguefeu[vg]) && ($('#' + toutevaguefeu[vg]).offset().left <= personnagetraigauche && document.getElementById(toutevaguefeu[vg]).clientWidth + $('#' + toutevaguefeu[vg]).offset().left >= personnagetraigauche && $('#' + toutevaguefeu[vg]).offset().top < personnagetraibas && document.getElementById(toutevaguefeu[vg]).clientHeight + $('#' + toutevaguefeu[vg]).offset().top > personnagetraihaut || document.getElementById(toutevaguefeu[vg]).clientWidth + $('#' + toutevaguefeu[vg]).offset().left >= personnagetraidroite && $('#' + toutevaguefeu[vg]).offset().left <= personnagetraidroite && $('#' + toutevaguefeu[vg]).offset().top < personnagetraibas && document.getElementById(toutevaguefeu[vg]).clientHeight + $('#' + toutevaguefeu[vg]).offset().top > personnagetraihaut)) {
                        jaugevie -= degatvagueflamme
                        $('#personnage').offset({ left: leftpersonnage -20 })
                    }
                    break;
                case 'droite':
                if (document.getElementById(toutevaguefeu[vg]) && ($('#' + toutevaguefeu[vg]).offset().left <= personnagetraigauche && document.getElementById(toutevaguefeu[vg]).clientWidth + $('#' + toutevaguefeu[vg]).offset().left >= personnagetraigauche && $('#' + toutevaguefeu[vg]).offset().top < personnagetraibas && document.getElementById(toutevaguefeu[vg]).clientHeight + $('#' + toutevaguefeu[vg]).offset().top > personnagetraihaut || document.getElementById(toutevaguefeu[vg]).clientWidth + $('#' + toutevaguefeu[vg]).offset().left >= personnagetraidroite && $('#' + toutevaguefeu[vg]).offset().left <= personnagetraidroite && $('#' + toutevaguefeu[vg]).offset().top < personnagetraibas && document.getElementById(toutevaguefeu[vg]).clientHeight + $('#' + toutevaguefeu[vg]).offset().top > personnagetraihaut)) {
                        jaugevie -= degatvagueflamme
                        $('#personnage').offset({ left: leftpersonnage + 20 })
                    }
                    break;
        }
    }
}
function contactesentore() {
    leftbosssentored = $('#bosssentored').offset().left
    topbosssentored = $('#bosssentored').offset().top
    bosssentoredtraidroite = taillehorizontalbosssentored + leftbosssentored
    bosssentoredtraigauche = leftbosssentored
    bosssentoredtraihaut = topbosssentored
    bosssentoredtraibas = taillehauteurbosssentored + topbosssentored
    if (!sentoretourdie && (bosssentoredtraigauche <= personnagetraigauche && bosssentoredtraidroite >= personnagetraigauche && bosssentoredtraihaut < personnagetraibas && bosssentoredtraibas > personnagetraihaut || bosssentoredtraidroite >= personnagetraidroite && bosssentoredtraigauche <= personnagetraidroite && bosssentoredtraihaut < personnagetraibas && bosssentoredtraibas > personnagetraihaut)) {
        jaugevie -= 2
    } else if (sentoretourdie && (bosssentoredtraigauche <= personnagetraigauche && bosssentoredtraidroite >= personnagetraigauche && bosssentoredtraihaut < personnagetraibas && bosssentoredtraibas > personnagetraihaut || bosssentoredtraidroite >= personnagetraidroite && bosssentoredtraigauche <= personnagetraidroite && bosssentoredtraihaut < personnagetraibas && bosssentoredtraibas > personnagetraihaut)) {
        viebosssentored -= 10
    }
    for (p in listepierre) {
        if (document.getElementById(listepierre[p]) && (bosssentoredtraigauche <= $('#' + listepierre[p]).offset().left && bosssentoredtraidroite >= $('#' + listepierre[p]).offset().left && bosssentoredtraihaut < document.getElementById(listepierre[p]).clientHeight + $('#' + listepierre[p]).offset().top && bosssentoredtraibas > $('#' + listepierre[p]).offset().top || bosssentoredtraidroite >= document.getElementById(listepierre[p]).clientWidth + $('#' + listepierre[p]).offset().left && bosssentoredtraigauche <= document.getElementById(listepierre[p]).clientWidth + $('#' + listepierre[p]).offset().left && bosssentoredtraihaut < document.getElementById(listepierre[p]).clientHeight + $('#' + listepierre[p]).offset().top && bosssentoredtraibas > $('#' + listepierre[p]).offset().top)) {
            sentoretourdie = true
            viebosssentored -=50
            destructionpierre(listepierre[p])
        }
    }
}
