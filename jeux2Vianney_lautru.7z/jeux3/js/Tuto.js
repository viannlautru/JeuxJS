async function tuto() {
	while (stop) {
		var nombre = 1;
		textetuto()
		nombredemechanttotal += nombre
		while (monstretuer < nombre) {
			await delay(100)
		}
		monstretuer =0
		await delay(1000)
		textetutodel()
	}
}

function textetuto() {
	document.getElementById('textetuto').style.display = "";
}
function textetutodel() {
	document.getElementById('textetuto').style.display = "none";
}
