var mouvboulefeutrace
var contactavecboulle
var mouvvaguefeu
var avancervaguefeu
var lanceanimevague
var contactevaguefeu
var rotabouleboulle
var contacttitan
var contactedusentore
var pierreaparition

function lancetitanfeu() {
    titanfeu()
    lanceboulledefeu()
    lancevaguefeu()
    lanceanimationdutitanfeu()
    animationtitan()
}
function lanceSentor() {
    sentormort = false
    sentor()
    lancecontactesentore()
    animationsentor()
}
function stopSentor() {
    stopcontactesentore()
}
function stoptitan() {
    stopboulledefeu()
    stopvaguefeu()
    stoplanceanimationdutitanfeu()
}
function lancecontactesentore() {
    contactedusentore = setInterval(contactesentore, 10)
    pierreaparition = setInterval(pierresentor,10)
}
function stopcontactesentore() {
    clearInterval(contactedusentore);
    contactedusentore = null;
    clearInterval(pierreaparition);
    pierreaparition = null;
}
function lanceboulledefeu() {
    mouvboulefeutrace = setInterval(contactboule, 10);
    contactavecboulle = setInterval(lanceboulle, 5);
    rotabouleboulle = setInterval(boullerotate, 10);
    contacttitan = setInterval(contactbouletitan, 10);
}
function lancevaguefeu() {
    mouvvaguefeu = setInterval(directionflamme, 10);
    avancervaguefeu = setInterval(vaguefeuavance, 10);
    contactevaguefeu = setInterval(contactvaguefeu, 10);
}
function stopvaguefeu() {
    clearInterval(mouvvaguefeu);
    mouvvaguefeu = null;
    clearInterval(avancervaguefeu);
    avancervaguefeu = null;
    clearInterval(contactevaguefeu);
    contactevaguefeu = null;
}
function lanceanimationdutitanfeu() {
    lanceanimevague = setInterval(animationvagueflame, 10);
}
function stoplanceanimationdutitanfeu() {
    clearInterval(lanceanimevague);
    lanceanimevague = null;
}
function stopboulledefeu() {
    clearInterval(mouvboulefeutrace);
    mouvboulefeutrace = null;
    clearInterval(contactavecboulle);
    contactavecboulle = null;
    clearInterval(rotabouleboulle );
    rotabouleboulle  = null;
    clearInterval(contacttitan);
    contacttitan = null;
}
