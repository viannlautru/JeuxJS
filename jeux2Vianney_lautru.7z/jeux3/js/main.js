
var imgPersonnage = document.createElement("img");
imgPersonnage.src = "./img/personnage2.png";
var imgTime = document.createElement("img");
imgTime.src = "./img/time.png";
var imgoraatk = document.createElement("img");
imgoraatk.src = "./img/Orattack0.png";
var imgvie = document.createElement("img");
imgvie.src = "./img/vie.png";
var imggemme = document.createElement("img");
imggemme.src = "./img/jaugegemme.png";


var nomjoueur = null
var corbeau = false
var jaugegemme = 0
var nombredemechantcontant = 0;
var nombredemechanttotal = 0;
let mechant1 = [];
let viemechant1 = []
var firstmechant = true
var sourisY
var sourisX
var stop = true
var firstgemme = true
var firstexplo = true
var firstlaser =true
var angle = 0;
var mouvementenemie = true
let mortmechanttop = []
let mortmechantleft = []
let etatexplosion = []
let listescore = []
var autoattaque = false
var taillehauteurMap
var taillehorizontalMap

var viecorbeau = 5
var viecorbeaugene = 5
var DegatMechant = 20
var VieMechant = 20
///Les States Personnages
var jaugevie = 100
var Valeurgemme = 20
var espacelumiereperso = 500
var espacelumierepersocorbeau = 200
var delayautoattaque = 5000
var Degatorak = 20

var delayfuser = 5000
var nombrefuser = 1
var lancementartifice = false
var Degatfuser = 10
var DegatExplosion = 10

var delaylaserattaque = 5000
var DegatLaser = 10
var laserActive = false
var niv2laser = false
var niv3laser = false
var niv4laser = false

var bouclierActive = false
var delayraparitionblouclier = 10000
var viebouclier = 100
var monstretuer = 0
var bosstuer = 0
var scoretotal = 0
//BBOOOSSS
var vietitanfeugene=50




fenetreheight = window.innerHeight;
fenetrewidth = window.innerWidth;
Centretop = (fenetreheight / 2)
Centreleft = (fenetrewidth / 2)

fenetretraidroite = fenetreheight
fenetretraigauche = 0
fenetretraihaut = 0
fenetretraibas = fenetreheight

Topup = Centretop - 100
Topdown = Centretop + 100
leftleft = Centreleft - 100
leftright = Centreleft + 100

imgPersonnage.id = "personnage";
document.body.appendChild(imgPersonnage);
document.getElementById("Personnage").appendChild(imgPersonnage);

imgoraatk.id = "oratk";
document.body.appendChild(imgoraatk);
document.getElementById("Personnage").appendChild(imgoraatk);


idmap = document.getElementById('Map')
idperso = document.getElementById('personnage')
idoratk = document.getElementById('oratk')


$('#mechant').offset({ left: 500, top: 800 })
$('#personnage').offset({ left: Centreleft, top: Centretop })



taillehauteurMap = idmap.clientHeight
taillehorizontalMap = idmap.clientWidth


var marche = false

taillehauteurpersonnage = idperso.clientHeight
taillehorizontalpersonnage = idperso.clientWidth


var o = 0
var g = 0
var gr = 0
document.getElementById('state').style.display = "none";
document.getElementById('classements').style.display = "none";
document.getElementById('newcomp').style.display = "none";
document.getElementById('textetuto').style.display = "none";

document.getElementById("CadreJeux").style.display = "none";

function play(n) {
    document.getElementById("menugen").style.display = "none";
    document.getElementById("CadreJeux").style.display = "";
    setup()
   
    if (n == 1) modeHistoire()
    else if (n == 2) jeuxLibre()
    else if (n == 3) Tutojeux()
    var soundjeu = new Audio('./sound/soundjeu.mp3');
    soundjeu.play();

}

function setup() {
    imgTime.id = "timepann";
    document.body.appendChild(imgTime);
    document.getElementById("panneauaffiche").appendChild(imgTime);
    imgvie.id = "vie";
    document.body.appendChild(imgvie);
    document.getElementById("PV").appendChild(imgvie);
    imggemme.id = "jaugegemme";
    document.body.appendChild(imggemme);
    document.getElementById("degemme").appendChild(imggemme);
    
}



function dead() {
    stopmechant()
}
async function Clavier(e) {
    var keynum;
    if (window.event) // IE
    {
        keynum = e.keyCode;
    }
    else if (e.which) // Netscape/Firefox/Opera
    {
        keynum = e.which;
    }
        console.log(keynum)
    if (keynum == 69) nombredemechanttotal += 1
    if (keynum == 65) stopTous()
    if (keynum == 90) lanceTous()
    if (keynum == 88) lelaser()
    if (keynum == 87) {
        tiragecompt()
        stopTous()
        stop = false
    }
    if (keynum == 67) nombredevaguefeutracetotal+=1
    if (keynum == 81) {}
    if (keynum == 86) {
        aparitionportail()
        /*corbeauactive()*/
        /*lanceSentor()*/
    }
}



function Mort() {
    stopTous()
}
function amelioration() {
    stopTous()
    tiragecompt()
}
function mousemove(event) {
    sourisY = event.clientY 
    sourisX = event.clientX
}
window.addEventListener('mousemove', mousemove);
function delay(time) {
    return new Promise(resolve => setTimeout(resolve, time));
}


