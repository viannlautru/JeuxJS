var mechantapparue = 0
var apparitionfinit = false
var portail = false
var nombre
async function modeaventure() {
	while (stop) {
		nombre = Math.floor((Math.random() * (50 - 30)) + 30) + monstretuer;
		aparitionmechant(nombre)
		while (monstretuer < nombre) {
			await delay(100)
		}
		aparitionportail()
			await delay(1000)
	}
}
async function aparitionmechant(nombre) {
	mechantapparue = 0
	apparitionfinit = false
	while (nombre >= mechantapparue) {
		var mechantapparition = Math.floor(((Math.random() * 5) + 2));
		mechantapparue += mechantapparition
		if (mechantapparue > nombre) nombredemechanttotal += mechantapparue - nombre
		else nombredemechanttotal += mechantapparition
		await delay(5000)
	}
	apparitionfinit = true
}
function aparitionportail() {
	var imgportail = document.createElement("img");
	imgportail.src = "./img/portail1.png";
	//----------------Mechant1-------------------
	imgportail.id = "portail";
	document.body.appendChild(imgportail);
	document.getElementById("Map").appendChild(imgportail);
	taillehauteurportail = document.getElementById("portail").clientHeight
	taillehorizontalportail = document.getElementById("portail").clientWidth
	leftportail = $('#portail').offset().left
	topportail = $('#portail').offset().top
	portailcentrehauteur = (taillehauteurportail / 2)
	portailcentrelargeur = (taillehorizontalportail / 2)
	$('#portail').offset({ left: MapCentreLargeur - portailcentrelargeur, top: MapCentreHauteur - portailcentrelargeur })
	portail = true
	animationportail()
	contactportail()
}
function deleteportail() {
	document.getElementById('portail').remove()
	portail = false
}

function map() {
	var mapalea = Math.floor(((Math.random() * 3) + 1));

	switch (mapalea) {
		case 1:
			document.getElementById('Map').className = "Map2"
			break;
		case 2:
			document.getElementById('Map').className = "Map"
			break;
		case 3:
			document.getElementById('Map').className = "Map3"
			break;
	}
	taillehauteurMap = idmap.clientHeight
	taillehorizontalMap = idmap.clientWidth
	deleteportail()
}