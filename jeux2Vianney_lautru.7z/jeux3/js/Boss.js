let bouledefeu = []
let bouledefeutrace = []
var nombredebouledefeutracecontant = 0
var nombredevaguefeutracecontant = 0
var nombredevaguefeutracetotal =1
var numboulefeu =1
var vietitanfeu = 50
let angleboulledefeu = []
let Etatboulle = []
let boullerot = []
let directiontop = []
let directionleft = []
let toutevaguefeu = []
let directionvaguefeu = []
var etatvagueflamme = []
var vitessevagueflamme = 2
var numbroboule = 3
var degatvagueflamme = 2
var encourdecrea = true
var morttitant = false
var fintitan = false
var viebosssentoredgene = 300
var vitessentor = 3
var timecharge = 500
var sentorsortie = true
var firspassagesentor = true
var sentormort = false
var sentoretourdie = false
var timeetourdie = 3000
var listepierre = []
var nbpierre = 0
var nbpierretotal = 1
var bloquesantore = 1201
var bossactive = false
function lanceunboss() {
    if (!bossactive) {
        bossactive = true
        var aleaboss = Math.floor(((Math.random() * 3) + 1));
        switch (aleaboss) {
            case 1:
                corbeauactive()
                break;
            case 2:
                lancetitanfeu()
                break;
            case 3:
                lanceSentor()
                break;
        }
    }
}


async function corbeauactive() {

    var imgcorbeau = document.createElement("img");
    imgcorbeau.src = "./img/corbeau1.png";
    //----------------Mechant1-------------------
    imgcorbeau.id = "corbeau";
    document.getElementById("bosszone").appendChild(imgcorbeau);
    viecorbeau = viecorbeaugene
    taillehauteurcorbeau = document.getElementById("corbeau").clientHeight
    taillehorizontalcorbeau = document.getElementById("corbeau").clientWidth
    $('#corbeau').offset({ left: retourleft(), top: retourtop() })

    tousnoire()
    corbeaulumiere()
    while (stop) {
        leftcorbeau = $('#corbeau').offset().left
        topcorbeau = $('#corbeau').offset().top
        corbeautraidroite = taillehorizontalcorbeau + leftcorbeau
        corbeautraigauche = leftcorbeau
        corbeautraihaut = topcorbeau
        corbeautraibas = taillehauteurcorbeau + topcorbeau

        centrecorbeauheight = taillehauteurcorbeau / 2
        centrecorbeauwidht = taillehorizontalcorbeau / 2
        await delay(100)
        if ($("#corbeau").offset().left < leftpersonnage) {
            if (!($("#corbeau").offset().left < leftpersonnage && $("#corbeau").offset().left + taillehorizontalcorbeau > leftpersonnage)) {
                $("#corbeau").offset({ left: $("#corbeau").offset().left + 3 })
                document.getElementById("corbeau").style.transform = 'rotateY(180deg)'
            }
        }
        else if ($("#corbeau").offset().left + taillehorizontalcorbeau > leftpersonnage) {
            if (!($("#corbeau").offset().left < leftpersonnage && $("#corbeau").offset().left + taillehorizontalcorbeau > leftpersonnage)) {
                $("#corbeau").offset({ left: $("#corbeau").offset().left - 3 })
                document.getElementById("corbeau").style.transform = 'rotateY(0deg)'
            }
        }
        if ($("#corbeau").offset().top < toppersonnage)
            $("#corbeau").offset({ top: $("#corbeau").offset().top + 3 })
        else if (document.getElementById("corbeau") && $("#corbeau").offset().top > toppersonnage)
            $("#corbeau").offset({ top: $("#corbeau").offset().top - 3 })
    }
}
async function corbeaulumiere() {

    var imgmap = document.createElement("img");
    imgmap.src = "./img/map2light.png";
    imgmap.id = "mapcorbeau";
    document.body.appendChild(imgmap);
    document.getElementById("bosszone").appendChild(imgmap);

    var positionlampleftcorb
    var positionlamptopcorb
    taillehauteurflout = document.getElementById("mapcorbeau").clientHeight
    taillehorizontalflout = document.getElementById("mapcorbeau").clientWidth
    centrefloutheight = taillehauteurflout / 2
    centrefloutwidht = taillehorizontalflout / 2

    corbeau = true

    animationcorbeau()
    while (stop) {
        await delay(1);
        $('#mapcorbeau').offset({ left: centrecorbeauwidht - espacelumierepersocorbeau / 2, top: centrecorbeauheight - espacelumierepersocorbeau / 2 })
        positionlampleftcorb = centrecorbeauwidht - espacelumierepersocorbeau / 2
        positionlamptopcorb = centrecorbeauheight - espacelumierepersocorbeau / 2
        document.getElementById("mapcorbeau").style.paddingTop = (-positionlamptopcorb) + "px"
        document.getElementById("mapcorbeau").style.paddingLeft = (-positionlampleftcorb) + "px"
        document.getElementById("mapcorbeau").style.clip = "rect(" + topcorbeau + "px, " + (espacelumierepersocorbeau + leftcorbeau) + "px, " + (espacelumierepersocorbeau + topcorbeau) + "px, " + leftcorbeau + "px)";
    }
}
async function sentor() {
    var imgbosssentored = document.createElement("img");
    imgbosssentored.src = "./img/animesentor/bosssentored.png";
    //----------------Mechant1-------------------
    imgbosssentored.id = "bosssentored";
    document.body.appendChild(imgbosssentored);
    document.getElementById("bosszone").appendChild(imgbosssentored);
    viebosssentored = viebosssentoredgene
    taillehauteurbosssentored = document.getElementById("bosssentored").clientHeight
    taillehorizontalbosssentored = document.getElementById("bosssentored").clientWidth
    bosssentoredcentrehauteur = (taillehauteurbosssentored / 2)
    bosssentoredcentrelargeur = (taillehorizontalbosssentored / 2)
    $('#bosszone').offset({ left: MapCentreLargeur - bosssentoredcentrelargeur, top: MapCentreHauteur - bosssentoredcentrehauteur })
    sentormort = false
    sentoretourdie = false
    while (!sentormort) {
        leftbosssentored = $('#bosssentored').offset().left
        topbosssentored = $('#bosssentored').offset().top
        bosssentoredtraidroite = taillehorizontalbosssentored + leftbosssentored
        bosssentoredtraigauche = leftbosssentored
        bosssentoredtraihaut = topbosssentored
        bosssentoredtraibas = taillehauteurbosssentored + topbosssentored
        //if (bloquesantore <= 1200) {
        //    debugdirection()
        //} else
            directionsentor()
        bloquesantore = 0
        sentorsortie = true
        firspassagesentor = true
        while (sentorsortie) {
            if (viebosssentored <= 0) {
                sentormort = true
                bossactive = false
                suppsentor()
                sentorsortie = false
                bosstuer++ 
            }else if (firspassagesentor || $('#bosssentored').offset().left >= Maptraigauche && $('#bosssentored').offset().left + taillehorizontalbosssentored <= Maptraidroite && $('#bosssentored').offset().top + bosssentoredcentrehauteur <= Maptraibas && $('#bosssentored').offset().top >= Maptraihaut) {
                $('#bosssentored').offset({ left: $('#bosssentored').offset().left + directionleftsentor, top: $('#bosssentored').offset().top + directiontopsentor })
                firspassagesentor = false
                await delay(1)
            } else {
                directionsentor()
                sentorsortie = false
            }
            if (sentoretourdie) {
                sentorsortie = false
                await delay(timeetourdie)
                sentoretourdie = false
                directionsentor()
            }
            bloquesantore +=1
        }
        await delay(timecharge)
    }

}
function suppsentor() {
    nbpierre = 0
    nbpierretotal = 1
    stopSentor()
    document.getElementById('bosssentored').remove()
    while (listepierre.length != 0) {
        for (var pierre in listepierre) {
            if (listepierre.indexOf(listepierre[pierre]) !== -1)  listepierre.splice(listepierre.indexOf(listepierre[pierre]), 1);
        }
    }
}
function debugdirection() {
    const angle = Math.atan2(
        ($('#personnage').offset().top + centreperosnnageheight) - (topbosssentored + bosssentoredcentrehauteur),
        ($('#personnage').offset().left + centreperosnnagewidht) - (leftbosssentored + bosssentoredcentrelargeur)
    )
    directionleftsentor = -Math.cos(angle)
    directiontopsentor = -Math.sin(angle)
    if (directionleftsentor < 0) directionleftsentor -= vitessentor
    else directionleftsentor += vitessentor
    if (directiontopsentor < 0) directiontopsentor -= vitessentor
    else directiontopsentor += vitessentor
}
function directionsentor() {
    const angle = Math.atan2(
        ($('#personnage').offset().top + centreperosnnageheight) - (topbosssentored + bosssentoredcentrehauteur),
        ($('#personnage').offset().left + centreperosnnagewidht) - (leftbosssentored + bosssentoredcentrelargeur)
    )
    directionleftsentor = Math.cos(angle)
    directiontopsentor = Math.sin(angle)
    if (directionleftsentor < 0) directionleftsentor -= vitessentor
    else directionleftsentor += vitessentor
    if (directiontopsentor < 0) directiontopsentor -= vitessentor
    else directiontopsentor += vitessentor
}
async function pierresentor() {

    while (nbpierre < nbpierretotal) {
        var imgpierre = document.createElement("img");
        imgpierre.src = "./img/pierre1.png";
        //----------------Mechant1-------------------
        imgpierre.id = "pierre" + nbpierre;
        document.body.appendChild(imgpierre);
        document.getElementById("bosszone").appendChild(imgpierre);
        document.getElementById("pierre" + nbpierre).className = "pierre"
        taillehauteurpierre = document.getElementById("pierre" + nbpierre).clientHeight
        taillehorizontalpierre = document.getElementById("pierre" + nbpierre).clientWidth
        pierrecentrehauteur = (taillehauteurpierre / 2)
        pierrecentrelargeur = (taillehorizontalpierre / 2)
        var aleatop = Math.floor(((Math.random() * (Maptraibas - Maptraihaut)) + Maptraihaut));
        var alealeft = Math.floor(((Math.random() * (Maptraidroite - Maptraigauche)) + Maptraigauche));
        $('#pierre' + nbpierre).offset({ left: alealeft, top: aleatop })
        listepierre.push("pierre" + nbpierre)
        nbpierre+=1
    }
}
async function titanfeu() {
    fintitan = false
    var imgtitanfeu = document.createElement("img");
    imgtitanfeu.src = "./img/titanfeu1.png";
    //----------------Mechant1-------------------
    imgtitanfeu.id = "titanfeu";
    document.body.appendChild(imgtitanfeu);
    document.getElementById("bosszone").appendChild(imgtitanfeu);
    vietitanfeu = vietitanfeugene
    taillehauteurtitanfeu = document.getElementById("titanfeu").clientHeight
    taillehorizontaltitanfeu = document.getElementById("titanfeu").clientWidth
    lefttitanfeu = $('#titanfeu').offset().left
    toptitanfeu = $('#titanfeu').offset().top
    titanfeutraidroite = taillehorizontaltitanfeu + lefttitanfeu 
    titanfeutraigauche = lefttitanfeu
    titanfeutraihaut = toptitanfeu
    titanfeutraibas = taillehauteurtitanfeu + toptitanfeu
    titanfeucentrehauteur = (taillehauteurtitanfeu/2)
    titanfeucentrelargeur = (taillehorizontaltitanfeu / 2)
    $('#titanfeu').offset({ left: MapCentreLargeur - titanfeucentrelargeur, top: MapCentreHauteur - titanfeucentrelargeur})
    morttitant = false
    while (!morttitant) {
        lefttitanfeu = $('#titanfeu').offset().left
        toptitanfeu = $('#titanfeu').offset().top
        titanfeutraidroite = taillehorizontaltitanfeu + lefttitanfeu
        titanfeutraigauche = lefttitanfeu
        titanfeutraihaut = toptitanfeu
        titanfeutraibas = taillehauteurtitanfeu + toptitanfeu
        attaquetitan = Math.floor(((Math.random() * 500) + 1))
        if (attaquetitan == 1) nombredevaguefeutracetotal += 1
        else {
            unoudeux = Math.floor(((Math.random() * 2) + 1))
            createboulle(unoudeux)
        }

        //$('#titanfeu').offset({ left: $('#titanfeu').offset().left+1, top: $('#titanfeu').offset().top+1  })
        if (vietitanfeu <= 0) {
            morttitant = true
            bossactive = false
            supptous()
            bosstuer++
            while (!fintitan) {
                if (!encour) {
                    document.getElementById("titanfeu").remove()
                    fintitan = true
                    stoptitan()
                }
                await delay(1)
            }
        }
        await delay(10)
    }
}
async function supptous() {
    encour = true
    while (bouledefeu.length !=0) {
        for (var tousboul in bouledefeu) {
            suppboulle(tousboul)
        }
        await delay(100)
    }
    await delay(1)
    while (toutevaguefeu.length != 0) {
        for (var toutvague in toutevaguefeu) {
            removevague(toutvague)
        }
        await delay(100)
    }
    encour = false
}
async function createboulle(n) {
    if (encourdecrea) {
        encourdecrea=false
        while (numboulefeu <= numbroboule) {
            var imgbouledefeu = document.createElement("img");
            designboule = Math.floor(((Math.random() * 2) + 1))
            imgbouledefeu.src = "./img/bouledefeu" + designboule + ".png";
            if (designboule == 1)
                Etatboulle.push(0)
            else
                Etatboulle.push(3)
            //----------------Boule de feu-------------------
            imgbouledefeu.id = "bouledefeu" + nombredebouledefeutracecontant;
            document.getElementById("bosszone").appendChild(imgbouledefeu);
            document.getElementById("bouledefeu" + nombredebouledefeutracecontant).className = "bouledefeu"
            taillehauteurbouledefeu = document.getElementById("bouledefeu" + nombredebouledefeutracecontant).clientHeight
            taillehorizontalbouledefeu = document.getElementById("bouledefeu" + nombredebouledefeutracecontant).clientWidth
            lefttitanfeu = $('#titanfeu').offset().left
            toptitanfeu = $('#titanfeu').offset().top
            Centrebouledefeuhauteur = (taillehauteurbouledefeu / 2)
            Centrebouledefeulargeur = (taillehorizontalbouledefeu / 2)
            bouledefeu.push("bouledefeu" + nombredebouledefeutracecontant)
            angleboulledefeu.push(1)
            boullerot.push(0.2)
            const angle = Math.atan2(
                ($('#personnage').offset().top + centreperosnnageheight) - (titanfeucentrehauteur + toptitanfeu - Centrebouledefeuhauteur),
                ($('#personnage').offset().left + centreperosnnagewidht) - (lefttitanfeu - Centrebouledefeulargeur)
            )
            directionleft.push(Math.cos(angle))
            directiontop.push(Math.sin(angle))
            if (n == 1)
                bouledefeutrace.push("rota")
            else if (n == 2)
                bouledefeutrace.push("ligne")

            $('#bouledefeu' + nombredebouledefeutracecontant).offset({ left: lefttitanfeu - Centrebouledefeulargeur, top: titanfeucentrehauteur + toptitanfeu - Centrebouledefeuhauteur })
            numboulefeu += 1
            nombredebouledefeutracecontant += 1

            await delay(500)
        }
        numboulefeu = 0
        encourdecrea=true
    }
}
async function lanceboulle() {
    for (var a1 in bouledefeu) {
        if (document.getElementById(bouledefeu[a1]) && bouledefeutrace[a1] =="ligne") {
            if (document.getElementById(bouledefeu[a1]) && $("#" + bouledefeu[a1]).offset().left >= Maptraigauche && $("#" + bouledefeu[a1]).offset().left + taillehorizontalbouledefeu <= Maptraidroite && $("#" + bouledefeu[a1]).offset().top + taillehauteurbouledefeu <= Maptraibas && $("#" + bouledefeu[a1]).offset().top >= Maptraihaut) {
                $('#' + bouledefeu[a1]).offset({ left: $('#' + bouledefeu[a1]).offset().left + directionleft[a1], top: $('#' + bouledefeu[a1]).offset().top + directiontop[a1] })
            } else {
                suppboulle(a1)
             }
        }
    }
}
function suppboulle(n) {
    etatexplosion.push(0)
    exploartifice.push(bouledefeu[n])
    if (bouledefeu.indexOf(bouledefeu[n]) !== -1) {
        boullerot.splice(boullerot.indexOf(boullerot[n]), 1);
        angleboulledefeu.splice(angleboulledefeu.indexOf(angleboulledefeu[n]), 1);
        bouledefeu.splice(bouledefeu.indexOf(bouledefeu[n]), 1);
        directionleft.splice(directionleft.indexOf(directionleft[n]), 1);
        directiontop.splice(directiontop.indexOf(directiontop[n]), 1);
        Etatboulle.splice(Etatboulle.indexOf(Etatboulle[n]), 1);
        bouledefeutrace.splice(bouledefeutrace.indexOf(bouledefeutrace[n]), 1);
    }
}
async function boullerotate() {
            for (var bf in bouledefeu) {
                if (document.getElementById(bouledefeu[bf]) && bouledefeutrace[bf] == "rota") {

                    await delay(1)
                    lefttitanfeu = $('#titanfeu').offset().left
                    toptitanfeu = $('#titanfeu').offset().top

                    $('#' + bouledefeu[bf]).offset({ left: (titanfeucentrelargeur + lefttitanfeu) + (boullerot[bf]) * Math.cos(angleboulledefeu[bf] / 180 * Math.PI), top: (titanfeucentrehauteur + toptitanfeu) + (boullerot[bf]) * Math.sin(angleboulledefeu[bf] / 180 * Math.PI) })
                    boullerot[bf] += 1
                    angleboulledefeu[bf] += 1
                    if (boullerot[bf] >= 1000) {
                        suppboulle(bf)
                    }
                }
            }
            await delay(1)
}
async function vaguefeuavance() {
    for (var vg in toutevaguefeu) {
        lefttitanfeu = $('#titanfeu').offset().left
        toptitanfeu = $('#titanfeu').offset().top
        switch (directionvaguefeu[vg]) {

            case 'haut':
                $('#' + toutevaguefeu[vg]).offset({ top: $('#' + toutevaguefeu[vg]).offset().top - vitessevagueflamme })
                break;
            case 'bas':
                $('#' + toutevaguefeu[vg]).offset({ top: $('#' + toutevaguefeu[vg]).offset().top + vitessevagueflamme })
                break;
            case 'gauche':
                $('#' + toutevaguefeu[vg]).offset({ left: $('#' + toutevaguefeu[vg]).offset().left - vitessevagueflamme, top: titanfeucentrehauteur + toptitanfeu - (document.getElementById(toutevaguefeu[vg]).clientHeight / 2)  })
                break;
            case 'droite':
                $('#' + toutevaguefeu[vg]).offset({ left: $('#' + toutevaguefeu[vg]).offset().left + vitessevagueflamme, top: titanfeucentrehauteur + toptitanfeu - (document.getElementById(toutevaguefeu[vg]).clientHeight / 2)   })
                break;
            case 'gauchebastdiag':
                $('#' + toutevaguefeu[vg]).offset({ left: $('#' + toutevaguefeu[vg]).offset().left - vitessevagueflamme, top: $('#' + toutevaguefeu[vg]).offset().top + vitessevagueflamme })
                break;
            case 'droitehautdiag':
                $('#' + toutevaguefeu[vg]).offset({ left: $('#' + toutevaguefeu[vg]).offset().left + vitessevagueflamme, top: $('#' + toutevaguefeu[vg]).offset().top - vitessevagueflamme })
                break;
            case 'gauchehautdiag':
                $('#' + toutevaguefeu[vg]).offset({ left: $('#' + toutevaguefeu[vg]).offset().left - vitessevagueflamme, top: $('#' + toutevaguefeu[vg]).offset().top - vitessevagueflamme })
                break;
            case 'droitebasdiag':
                $('#' + toutevaguefeu[vg]).offset({ left: $('#' + toutevaguefeu[vg]).offset().left + vitessevagueflamme, top: $('#' + toutevaguefeu[vg]).offset().top + vitessevagueflamme })
                break;
        }
        etatvagueflamme[vg] +=1
    }
}
function removevague(vague) {
    document.getElementById(toutevaguefeu[vague]).remove()
    if (toutevaguefeu.indexOf(toutevaguefeu[vague]) !== -1) {
        toutevaguefeu.splice(toutevaguefeu.indexOf(toutevaguefeu[vague]), 1);
        etatvagueflamme.splice(etatvagueflamme.indexOf(etatvagueflamme[vague]), 1);
        directionvaguefeu.splice(directionvaguefeu.indexOf(directionvaguefeu[vague]), 1);
    }
}
async function vaguedefeu(position,tragectoir) {
    while (nombredevaguefeutracecontant < nombredevaguefeutracetotal) {
        var imgvaguefeu = document.createElement("img");
        if (tragectoir == "Droit") {
            imgvaguefeu.src = "./img/vaguedefeu1.png";
        } else {
            imgvaguefeu.src = "./img/vaguedefeudiag1.png";
        }
        //----------------vague de feu-------------------
        imgvaguefeu.id = "vaguefeu" + nombredevaguefeutracecontant;
        document.getElementById("bosszone").appendChild(imgvaguefeu);
        if (tragectoir == "Droit") {
            document.getElementById("vaguefeu" + nombredevaguefeutracecontant).className = "vaguedefeu"
        } else {
            document.getElementById("vaguefeu" + nombredevaguefeutracecontant).className = "vaguedefeudiag"
        }
        taillehauteurvaguefeu = document.getElementById("vaguefeu" + nombredevaguefeutracecontant).clientHeight
        taillehorizontalvaguefeu = document.getElementById("vaguefeu" + nombredevaguefeutracecontant).clientWidth
        lefttitanfeu = $('#titanfeu').offset().left
        toptitanfeu = $('#titanfeu').offset().top
        Centrevaguefeuhauteur = (taillehauteurvaguefeu / 2)
        Centrevaguefeulargeur = (taillehorizontalvaguefeu / 2)
        toutevaguefeu.push("vaguefeu" + nombredevaguefeutracecontant)
        $('#vaguefeu' + nombredevaguefeutracecontant).offset({ left: titanfeucentrelargeur + lefttitanfeu - Centrevaguefeulargeur, top: titanfeucentrehauteur + toptitanfeu - Centrevaguefeuhauteur })
        etatvagueflamme.push(0)
        switch (position) {
            case 'haut':
                document.getElementById("vaguefeu" + nombredevaguefeutracecontant).style.transform = "rotate(90deg)"
                directionvaguefeu.push(position)
                break;
            case 'bas':
                document.getElementById("vaguefeu" + nombredevaguefeutracecontant).style.transform = "rotate(270deg)"
                directionvaguefeu.push(position)
                break;
            case 'gauche':
                document.getElementById("vaguefeu" + nombredevaguefeutracecontant).style.transform = "rotateY(0deg)"
                directionvaguefeu.push(position)
                break;
            case 'droite':
                document.getElementById("vaguefeu" + nombredevaguefeutracecontant).style.transform = "rotateY(180deg)"
                directionvaguefeu.push(position)
                break;
            case 'gauchebastdiag':
                document.getElementById("vaguefeu" + nombredevaguefeutracecontant).style.transform = "rotateY(0deg)"
                directionvaguefeu.push(position)
                break;
            case 'droitehautdiag':
                document.getElementById("vaguefeu" + nombredevaguefeutracecontant).style.transform = "rotate(180deg)"
                directionvaguefeu.push(position)
                break;
            case 'gauchehautdiag':
                document.getElementById("vaguefeu" + nombredevaguefeutracecontant).style.transform = "rotateX(180deg)"
                directionvaguefeu.push(position)
                break;
            case 'droitebasdiag':
                document.getElementById("vaguefeu" + nombredevaguefeutracecontant).style.transform = "rotateY(180deg)"
                directionvaguefeu.push(position)
                break;
        }
        nombredevaguefeutracecontant += 1
    }
}
async function directionflamme() {
    lefttitanfeu = $('#titanfeu').offset().left
    toptitanfeu = $('#titanfeu').offset().top
    const angleflamme = Math.atan2(
        ($('#personnage').offset().top + centreperosnnageheight) - (titanfeucentrehauteur + toptitanfeu),
        ($('#personnage').offset().left + centreperosnnagewidht) - (titanfeucentrelargeur + lefttitanfeu)
    )
    cibleleft = Math.cos(angleflamme)
    cibletop = Math.sin(angleflamme)
    if (lefttitanfeu <= leftpersonnage + (taillehorizontalpersonnage / 2) && lefttitanfeu + titanfeucentrelargeur >= leftpersonnage + (taillehorizontalpersonnage / 2)) {
        if (titanfeucentrehauteur + toptitanfeu >= toppersonnage + (taillehauteurpersonnage / 2)) {
            vaguedefeu("haut", "Droit")
        }
        else {
            vaguedefeu("bas", "Droit")
        }
    }
    if (toptitanfeu <= toppersonnage + (taillehauteurpersonnage / 2) && toptitanfeu + titanfeucentrehauteur >= toppersonnage + (taillehauteurpersonnage / 2)) {
        if (titanfeucentrelargeur + lefttitanfeu >= leftpersonnage + (taillehorizontalpersonnage / 2)) {
            vaguedefeu("gauche", "Droit")
        }
        else {
            vaguedefeu("droite", "Droit")
        }
    }
    if (cibleleft < 0.9 && cibleleft > 0.4 && cibletop > -0.9 && cibletop < -0.4 || cibleleft > -0.9 && cibleleft < -0.4 && cibletop < 0.9 && cibletop > 0.4) {
        if (titanfeucentrelargeur + lefttitanfeu >= leftpersonnage + (taillehorizontalpersonnage / 2)) {
            vaguedefeu("gauchebastdiag", "diag")
        }
        else {
            vaguedefeu("droitehautdiag", "diag")
        }
    }
    if (cibleleft < 0.9 && cibleleft > 0.4 && cibletop < 0.9 && cibletop > 0.4 || cibleleft > -0.9 && cibleleft < -0.4 && cibletop > -0.9 && cibletop < -0.4) {
        if (titanfeucentrelargeur + lefttitanfeu >= leftpersonnage + (taillehorizontalpersonnage / 2)) {
            vaguedefeu("gauchehautdiag", "diag")
        }
        else {
            vaguedefeu("droitebasdiag", "diag")
        }

    }
}
