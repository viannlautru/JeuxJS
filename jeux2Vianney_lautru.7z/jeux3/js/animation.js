async function animationtitanfeu() {
}
async function animationvagueflame() {
    for (var vg in toutevaguefeu) {
            switch (directionvaguefeu[vg]) {
                case 'gauche': case 'droite':case 'bas': case 'haut':
                    if (etatvagueflamme[vg] >= 100 ) {
                        document.getElementById(toutevaguefeu[vg]).className = "vaguedefeu2"
                        $("#" + toutevaguefeu[vg]).attr('src', "./img/vaguedefeu2.png ");
                    }
                    if (etatvagueflamme[vg] >= 200) {
                        document.getElementById(toutevaguefeu[vg]).className = "vaguedefeu3"
                        $("#" + toutevaguefeu[vg]).attr('src', "./img/vaguedefeu3.png ");
                    }
                    if (etatvagueflamme[vg] >= 300 ) {
                        document.getElementById(toutevaguefeu[vg]).className = "vaguedefeu4"
                        $("#" + toutevaguefeu[vg]).attr('src', "./img/vaguedefeu4.png ");
                    }
                    if (etatvagueflamme[vg] >= 350 ) {
                        removevague(vg)
                    }
                    break;
                case 'gauchehautdiag': case 'droitebasdiag': case 'droitehautdiag': case 'gauchebastdiag':
                    if (etatvagueflamme[vg] >= 100) {
                        document.getElementById(toutevaguefeu[vg]).className = "vaguedefeudiag2"
                        $("#" + toutevaguefeu[vg]).attr('src', "./img/vaguedefeudiag2.png ");
                    }
                    if (etatvagueflamme[vg] >= 200) {
                        document.getElementById(toutevaguefeu[vg]).className = "vaguedefeudiag3"
                        $("#" + toutevaguefeu[vg]).attr('src', "./img/vaguedefeudiag3.png ");
                    }
                    if (etatvagueflamme[vg] >= 300) {
                        document.getElementById(toutevaguefeu[vg]).className = "vaguedefeudiag4"
                        $("#" + toutevaguefeu[vg]).attr('src', "./img/vaguedefeudiag4.png ");
                    }
                    if (etatvagueflamme[vg] >= 350) {
                        removevague(vg)
                    }
                    break;
            }
        }
    }

async function animationsentor() {
    while (!sentormort) {
        chargesentor = 1
        $("#bosssentored").attr('src', "./img/animesentor/bosssentored.png ");
        while (chargesentor !=4) {
            $("#bosssentored").attr('src', "./img/animesentor/bosssentoredcharge" + chargesentor + ".png ");
            await delay(100)
            chargesentor += 1
        }
        await delay(1)
        n =1
        while (sentorsortie) {
            $("#bosssentored").attr('src', "./img/animesentor/bosssentoredcours" + n + ".png ");
            await delay(100)
            n += 1
            if (n >= 9) {
                n=1
            }
        }
        e=1
        while (sentoretourdie) {
            $("#bosssentored").attr('src', "./img/animesentor/bosssentoredetour" + e + ".png ");
            await delay(100)
            e += 1
            if (e >= 4) {
                e = 1
            }
        }
    }
}
async function destructionpierre(pierre) {
    if (listepierre.indexOf(pierre) !== -1) {
        listepierre.splice(listepierre.indexOf(pierre), 1);
    }
    n=1
    while (n < 4) {
        $("#" + pierre).attr('src', "./img/pierredestruct" + n + ".png ");
        await delay(100)
        n+=1
    }
    nbpierretotal += 1
    document.getElementById(pierre).remove()
}

async function animationtitan() {
    t=1
    while (!morttitant) {
        $("#titanfeu").attr('src', "./img/titanfeu" + t + ".png ");
        await delay(500)
        t += 1
        if (t >= 3) {
            t = 1
        }
    }
}
async function animationcorbeau() {
    c=1
    while (corbeau) {
        $("#corbeau").attr('src', "./img/corbeau" + c + ".png ");
        await delay(500)
        c += 1
        if (c >= 3) {
            c = 1
        }
    }
}
async function animationportail() {
    p=1
    while (portail) {
        $("#portail").attr('src', "./img/portail" + p + ".png ");
        await delay(200)
        p += 1
        if (p >= 4) {
            p = 1
        }
    }
}