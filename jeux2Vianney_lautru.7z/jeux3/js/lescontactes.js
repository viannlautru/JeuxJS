function collisionmechant() {
    if (mechant1.length > 0)  {
        for (var n1 in mechant1) {
            if (document.getElementById(mechant1[n1])) {
                if (document.getElementById(mechant1[n1]) && (personnagetraigauche <= $('#'+mechant1[n1]).offset().left && personnagetraidroite >= $('#'+mechant1[n1]).offset().left && personnagetraibas > $('#'+mechant1[n1]).offset().top && personnagetraihaut < taillehauteurmechant + $('#'+mechant1[n1]).offset().top || personnagetraigauche <= taillehorizontalmechant + $('#'+mechant1[n1]).offset().left && personnagetraidroite >= taillehorizontalmechant + $('#'+mechant1[n1]).offset().left && personnagetraibas > $('#'+mechant1[n1]).offset().top && personnagetraihaut < taillehauteurmechant + $('#'+mechant1[n1]).offset().top)) {
                    if (boucliertime) degatbouclier.push(DegatMechant)
                    else jaugevie -= DegatMechant
                    viemechant1[n1] -= viemechant1[n1]
                
                }
                if (document.getElementById(mechant1[n1]) && (oratktraigauche <= $('#' + mechant1[n1]).offset().left && oratktraidroite >= $('#'+mechant1[n1]).offset().left && oratktraibas > $('#'+mechant1[n1]).offset().top && oratktraihaut < taillehauteurmechant + $('#'+mechant1[n1]).offset().top || oratktraigauche <= taillehorizontalmechant + $('#'+mechant1[n1]).offset().left && oratktraidroite >= taillehorizontalmechant + $('#'+mechant1[n1]).offset().left && oratktraibas > $('#'+mechant1[n1]).offset().top && oratktraihaut < taillehauteurmechant + $('#'+mechant1[n1]).offset().top)) {
                    if (autoattaque) {
                        autoattaque = false
                        viemechant1[n1] -= Degatorak
                        var soundorak = new Audio('./sound/soundautoattaque.mp3');
                        soundorak.play();
                    }
                }
                if (corbeau) {
                    if (document.getElementById(mechant1[n1]) && (personnagetraigauche - espacelumiereperso / 2 <= $('#' + mechant1[n1]).offset().left && personnagetraidroite + espacelumiereperso / 2 >= $('#' + mechant1[n1]).offset().left && personnagetraibas + espacelumiereperso / 2 > $('#' + mechant1[n1]).offset().top && personnagetraihaut - espacelumiereperso / 2 < taillehauteurmechant + $('#' + mechant1[n1]).offset().top || personnagetraigauche + espacelumiereperso / 2 <= taillehorizontalmechant + $('#' + mechant1[n1]).offset().left && personnagetraidroite - espacelumiereperso / 2 >= taillehorizontalmechant + $('#' + mechant1[n1]).offset().left && personnagetraibas + espacelumiereperso / 2 > $('#' + mechant1[n1]).offset().top && personnagetraihaut - espacelumiereperso / 2 < taillehauteurmechant + $('#' + mechant1[n1]).offset().top)) {
                        document.getElementById(mechant1[n1]).style.zIndex = "5"
                        } else if (document.getElementById(mechant1[n1]) && (corbeautraigauche - espacelumierepersocorbeau / 2.5 <= $('#' + mechant1[n1]).offset().left && corbeautraidroite + espacelumierepersocorbeau / 2.5 >= $('#' + mechant1[n1]).offset().left && corbeautraibas + espacelumierepersocorbeau / 2.5 > $('#' + mechant1[n1]).offset().top && corbeautraihaut - espacelumierepersocorbeau / 2.5 < taillehauteurmechant + $('#' + mechant1[n1]).offset().top || corbeautraigauche + espacelumierepersocorbeau / 2.5 <= taillehorizontalmechant + $('#' + mechant1[n1]).offset().left && corbeautraidroite - espacelumierepersocorbeau / 2.5 >= taillehorizontalmechant + $('#' + mechant1[n1]).offset().left && corbeautraibas + espacelumierepersocorbeau / 2.5 > $('#' + mechant1[n1]).offset().top && corbeautraihaut - espacelumierepersocorbeau / 2.5 < taillehauteurmechant + $('#' + mechant1[n1]).offset().top)) {
                        document.getElementById(mechant1[n1]).style.zIndex = "5"
                    } else document.getElementById(mechant1[n1]).style.zIndex = "-1"
                }else document.getElementById(mechant1[n1]).style.zIndex = "1"
            }
        }
    }
    if (( oratktraigauche <= corbeautraigauche && oratktraidroite >= corbeautraigauche && oratktraibas > corbeautraihaut && oratktraihaut < corbeautraibas || oratktraigauche <= corbeautraidroite && oratktraidroite >= corbeautraidroite && oratktraibas > corbeautraihaut && oratktraihaut < corbeautraibas)) {
        if (autoattaque) {
            autoattaque = false
            viecorbeau -= Degatorak
            if (viecorbeau <= 0) {
                bossactive=false
                corbeau = false
                document.getElementById('corbeau').remove()
                document.getElementById('map').remove()
                document.getElementById('mapcorbeau').remove()
                document.getElementById("Map").style.background = ""
                bosstuer++
            }
            var soundorak = new Audio('./sound/soundautoattaque.mp3');
            soundorak.play();
        }
    }
}
async function colisionfusee() {
    if (mechant1.length > 0) {
        for (var n3 in mechant1) {
            for (var a1 in artifice) {
                if (lancementartifice) {
                    if (document.getElementById(artifice[a1]) && document.getElementById(mechant1[n3]) && ($('#' + artifice[a1]).offset().left <= $('#' + mechant1[n3]).offset().left && taillehorizontalartifice + $('#' + artifice[a1]).offset().left >= $('#' + mechant1[n3]).offset().left && taillehauteurartifice + $('#' + artifice[a1]).offset().top > $('#' + mechant1[n3]).offset().top && $('#' + artifice[a1]).offset().top < taillehauteurmechant + $('#' + mechant1[n3]).offset().top || $('#' + artifice[a1]).offset().left <= taillehorizontalmechant + $('#' + mechant1[n3]).offset().left && taillehorizontalartifice + $('#' + artifice[a1]).offset().left >= taillehorizontalmechant + $('#' + mechant1[n3]).offset().left && taillehauteurartifice + $('#' + artifice[a1]).offset().top > $('#' + mechant1[n3]).offset().top && $('#' + artifice[a1]).offset().top < taillehauteurmechant + $('#' + mechant1[n3]).offset().top)) {
                        exploartifice.push(artifice[a1])
                        etatexplosion.push(0)
                        if (artifice.indexOf(artifice[a1]) !== -1) {
                            artifice.splice(artifice.indexOf(artifice[a1]), 1);
                            artificeleft.splice(artificeleft.indexOf(artificeleft[a1]), 1);
                            artificetop.splice(artificetop.indexOf(artificetop[a1]), 1);
                        }
                        viemechant1[n3] -= Degatfuser
                    }
                }
            }
        }
    }
}

function colisionfuseeexplosion() {
        for (var exp in exploartifice) {
            if (document.getElementById(exploartifice[exp])) {
                if (etatexplosion[exp] == 4) {
                    document.getElementById(exploartifice[exp]).remove()
                    if (exploartifice.indexOf(exploartifice[exp]) !== -1) {
                        exploartifice.splice(exploartifice.indexOf(exploartifice[exp]), 1);
                        etatexplosion.splice(etatexplosion.indexOf(etatexplosion[exp]), 1);
                    }
                }
                else {
                    $("#" + exploartifice[exp]).attr('src', "./img/explosion" + etatexplosion[exp] + ".png ");
                    etatexplosion[exp] += 1
                    if (firstexplo) {
                        idexplo = document.getElementById(exploartifice[exp])
                        taillehauteurexplo = idexplo.clientHeight
                        taillehorizontalexplo = idexplo.clientWidth
                        firstartifice = false
                    }
                }
                for (var n3 in mechant1) {
                    if (document.getElementById(exploartifice[exp]) && document.getElementById(mechant1[n3]) && ($('#' + exploartifice[exp]).offset().left <= $('#' + mechant1[n3]).offset().left && taillehorizontalexplo + $('#' + exploartifice[exp]).offset().left >= $('#' + mechant1[n3]).offset().left && taillehauteurexplo + $('#' + exploartifice[exp]).offset().top > $('#' + mechant1[n3]).offset().top && $('#' + exploartifice[exp]).offset().top < taillehauteurmechant + $('#' + mechant1[n3]).offset().top || $('#' + exploartifice[exp]).offset().left <= taillehorizontalmechant + $('#' + mechant1[n3]).offset().left && taillehorizontalexplo + $('#' + exploartifice[exp]).offset().left >= taillehorizontalmechant + $('#' + mechant1[n3]).offset().left && taillehauteurexplo + $('#' + exploartifice[exp]).offset().top > $('#' + mechant1[n3]).offset().top && $('#' + exploartifice[exp]).offset().top < taillehauteurmechant + $('#' + mechant1[n3]).offset().top)) {
                        viemechant1[n3] -= DegatExplosion
                    }
                }
            }
           
        }
}
function contactegemme() {

    for (var gr in mortmechanttop) {
        var imgressource = document.createElement("img");
        imgressource.src = "./img/ressource0.png";
        imgressource.id = "ressource" + gemmeplus;
        etatgemme.push(0)
        delaygemme.push(0)
        document.body.appendChild(imgressource);
        document.getElementById("Personnage").appendChild(imgressource);
        document.getElementById("ressource" + gemmeplus).className = "gemme"
        $('#ressource' + gemmeplus).offset({ left: mortmechantleft[gr], top: mortmechanttop[gr] })
        if (firstgemme) {
            idressource = document.getElementById('ressource' + gemmeplus)
            taillehauteurressource = idressource.clientHeight
            taillehorizontalressource = idressource.clientWidth
            firstgemme = false
        }
        numgemme.push("ressource" + gemmeplus)
        gemmeplus +=1
        if (mortmechanttop.indexOf(mortmechanttop[gr]) !== -1) {
            mortmechanttop.splice(mortmechanttop.indexOf(mortmechanttop[gr]), 1);
            mortmechantleft.splice(mortmechantleft.indexOf(mortmechantleft[gr]), 1);
        }
    }
    for (var gn in numgemme) {
        if (document.getElementById(numgemme[gn])) {
            if (document.getElementById(numgemme[gn]) && (personnagetraigauche <= $('#' + numgemme[gn]).offset().left && personnagetraidroite >= $('#' + numgemme[gn]).offset().left && personnagetraibas > $('#' + numgemme[gn]).offset().top && personnagetraihaut < taillehauteurressource + $('#' + numgemme[gn]).offset().top || personnagetraigauche <= taillehorizontalressource + $('#' + numgemme[gn]).offset().left && personnagetraidroite >= taillehorizontalressource + $('#' + numgemme[gn]).offset().left && personnagetraibas > $('#' + numgemme[gn]).offset().top && personnagetraihaut < taillehauteurressource + $('#' + numgemme[gn]).offset().top)) {
                document.getElementById(numgemme[gn]).remove()
                if (numgemme.indexOf(numgemme[gr]) !== -1) {
                    numgemme.splice(numgemme.indexOf(numgemme[gr]), 1);
                    etatgemme.splice(etatgemme.indexOf(etatgemme[gr]), 1);
                }
                jaugegemme += Valeurgemme
                var soundgemme = new Audio('./sound/soundgemme.mp3');
                soundgemme.play();
            } else if (delaygemme[gn] >= 50 ) {
                document.getElementById(numgemme[gn]).remove()
                if (numgemme.indexOf(numgemme[gn]) !== -1) {
                    numgemme.splice(numgemme.indexOf(numgemme[gn]), 1);
                    delaygemme.splice(delaygemme.indexOf(delaygemme[gn]), 1);
                }
            } else
                delaygemme[gn] += 1
        }
        } 
}
async function removeallmechant() {
    while (mechant1.length != 0) {
        for (var mechant in mechant1) {
            suppmechant(mechant)
        }
        await delay(100)
    }
}
function suppmechant(n) {
    if (mechant1.indexOf(mechant1[n]) !== -1) {
        mechant1.splice(mechant1.indexOf(mechant1[n]), 1);
        viemechant1.splice(viemechant1.indexOf(viemechant1[n]), 1);
    }
}
function mortmechant() {
    if (mechant1.length > 0) {
        for (var m1 in viemechant1) {
            if (viemechant1[m1] <= 0) {
                mortmechantleft.push($('#' + mechant1[m1]).offset().left)
                mortmechanttop.push($('#' + mechant1[m1]).offset().top)
                document.getElementById(mechant1[m1]).remove()
                viemechant1.splice(viemechant1.indexOf(viemechant1[m1]), 1);
                mechant1.splice(mechant1.indexOf(mechant1[m1]), 1);
                monstretuer++ 
            }
        }
    }
}
async function contactportail() {
    while (portail) {

        taillehauteurportail = document.getElementById("portail").clientHeight
        taillehorizontalportail = document.getElementById("portail").clientWidth
        tailleuntier = taillehorizontalportail/3
        leftportail = $('#portail').offset().left
        topportail = $('#portail').offset().top
        if ((personnagetraidroite >= leftportail + tailleuntier && personnagetraidroite <= leftportail + taillehorizontalportail - tailleuntier && personnagetraibas > taillehauteurportail + topportail && personnagetraihaut <= taillehauteurportail + topportail || personnagetraigauche >= leftportail + tailleuntier  && personnagetraigauche <= taillehorizontalportail + leftportail - tailleuntier && personnagetraibas > taillehauteurportail+topportail && personnagetraihaut <= taillehauteurportail + topportail)) {
            map()
        }
        await delay(10)
    }
}