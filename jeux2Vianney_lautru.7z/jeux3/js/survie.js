async function lanceLibre() {
    while (stop) {
        var nombre = Math.floor(((Math.random() * 5) + 2));
        ajoutmechanttotal(nombre)
        if (sec2 / 30 >= 1 && sec2 / 30 <= 1.2) {
            if (!bossactive) {
                lanceunboss()
            }
        }
        await delay(5000)
    }
}

function ajoutmechanttotal(nombre) {
    if (bossactive)  nombredemechanttotal += 1
    else  nombredemechanttotal += nombre
}