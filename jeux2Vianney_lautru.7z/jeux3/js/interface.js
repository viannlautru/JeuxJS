async function tiragecompt() {
    
    document.getElementById('newcomp').style.display="";

    var c = 1
    while (c < 4) {
        var alea = Math.floor(((Math.random() * 9) + 1));
        if (alea == 5 && !lancementartifice || alea == 6 && !laserActive || alea == 7 && !laserActive || alea == 9 && !bouclierActive) {
                var alea = Math.floor(((Math.random() * 4) + 1));
        }
        switch (alea) {
            case 1:
                document.getElementById("comt" + c).setAttribute('onclick', 'fermecompt(),levelupsort(1),lanceTous()');
                document.getElementById("h1_compt" + c).innerHTML = "Laser";
                document.getElementById("util_compt" + c).innerHTML = "Un laser est projeter de vous et inflige des d�gats au enemis ";
                document.getElementById("degat_compt" + c).innerHTML = "10 de D�gat";
                break;
            case 2:
                document.getElementById("comt" + c).setAttribute('onclick', 'fermecompt(),levelupsort(2),lanceTous()');
                document.getElementById("h1_compt" + c).innerHTML = "Fus�e";
                document.getElementById("util_compt" + c).innerHTML = "Vous faite apparaitre des Fus�es � direction unique et qui explose au contacte des enemis";
                document.getElementById("degat_compt" + c).innerHTML = "10 de D�gat";
                break;
            case 3:
                document.getElementById("comt" + c).setAttribute('onclick', 'fermecompt(),levelupsort(3),lanceTous()');
                document.getElementById("h1_compt" + c).innerHTML = "Augmentation des d�gats";
                document.getElementById("util_compt" + c).innerHTML = "Votre oras fait plus de d�gat";
                document.getElementById("degat_compt" + c).innerHTML = "+5 de D�gat";
                break;
            case 4:
                document.getElementById("comt" + c).setAttribute('onclick', 'fermecompt(),levelupsort(4),lanceTous()');
                document.getElementById("h1_compt" + c).innerHTML = "Augmentation de la vitesse d'attaque";
                document.getElementById("util_compt" + c).innerHTML = "Votre oras attaque plus vite";
                document.getElementById("degat_compt" + c).innerHTML = "+1 seconde plus rapide";
                break;
            case 5:
                document.getElementById("comt" + c).setAttribute('onclick', 'fermecompt(),levelupsort(5),lanceTous()');
                document.getElementById("h1_compt" + c).innerHTML = "Augmentation des d�gats des fus�es";
                document.getElementById("util_compt" + c).innerHTML = "Vos fus�e ferons plus de degats";
                document.getElementById("degat_compt" + c).innerHTML = "+5 degats";
                break;

            case 6:
                document.getElementById("comt" + c).setAttribute('onclick', 'fermecompt(),levelupsort(6),lanceTous()');
                document.getElementById("h1_compt" + c).innerHTML = "Augmentation des d�gats des lasers";
                document.getElementById("util_compt" + c).innerHTML = "Vos laser ferons plus de d�gats";
                document.getElementById("degat_compt" + c).innerHTML = "+5 degats";
                break;

            case 7:
                document.getElementById("comt" + c).setAttribute('onclick', 'fermecompt(),levelupsort(7),lanceTous()');
                document.getElementById("h1_compt" + c).innerHTML = "Augmentation de la vitesse d'attaque des Laser";
                document.getElementById("util_compt" + c).innerHTML = "Vos laser attaque plus vite l'ennemis";
                document.getElementById("degat_compt" + c).innerHTML = "+1 seconde plus rapide";
                break;

            case 8:
                document.getElementById("comt" + c).setAttribute('onclick', 'fermecompt(),levelupsort(8),lanceTous()');
                if (!bouclierActive) {
                    document.getElementById("h1_compt" + c).innerHTML = "Activation du bouclier";
                    document.getElementById("util_compt" + c).innerHTML = "Un bouclier apparait autour de vous et peux suporter jusqu'� " + viebouclier + " de degats �nemis ";
                    document.getElementById("degat_compt" + c).innerHTML = "bouclier activ�";
                } else {
                    document.getElementById("h1_compt" + c).innerHTML = "Vie Bouclier";
                    document.getElementById("util_compt" + c).innerHTML = "Votre bouclier peux suporter jusqu'� " + viebouclier + " de degats �nemis ";
                    document.getElementById("degat_compt" + c).innerHTML = "+50 D�gats supporter";

                }
                break;
            case 9:
                document.getElementById("comt" + c).setAttribute('onclick', 'fermecompt(),levelupsort(9),lanceTous()');
                document.getElementById("h1_compt" + c).innerHTML = "Augmentation de la vitesse 'appararition de votre bouclier ";
                document.getElementById("util_compt" + c).innerHTML = "Votre Bouclier apparaitras plus vite l'orsque que celui ci est us�";
                document.getElementById("degat_compt" + c).innerHTML = "+1 seconde plus rapide";
                break;
        }
        await delay(10)
        c+=1
    }
}
function fermecompt() {
    document.getElementById('newcomp').style.display = "none";
}
function levelupsort(num) {

    stop = true
    switch (num) {
        case 1:
            if (!laserActive) { laserActive = true ;lelaser() }
            else {
                if (niv3laser) niv4laser = true
                if (niv2laser) niv3laser = true
                if (laserActive) niv2laser = true
            }
            break;
        case 2:
            if (!lancementartifice) attaartificedelayfun();
            else {
                if (nombrefuser == 2) nombrefuser = 3
                if (nombrefuser == 1) nombrefuser = 2
            }
            break;
        case 3:
            Degatorak += 5
            break;
        case 4:
            delayautoattaque -= 1000
            break;
        case 5:
            DegatExplosion += 5
            break;
        case 6:
            DegatLaser += 5
            break;
        case 7:
            delaylaserattaque -= 1000
            break;
        case 8:
            if (!bouclierActive) Bouclier()
            else viebouclier += 50
            break;
        case 9:
            delayraparitionblouclier -= 1000
            break;
    }
}
function returmenu() {
    document.getElementById("menugen").style.display = "";
    document.getElementById("CadreJeux").style.display = "none";
    quitter()
}
function quitter() {
    location.reload();
}
function name() {
    nomjoueur = document.getElementById("name").value;
}
function affichestate() {
    document.getElementById('state').style.display = "";
    let newP = document.createElement('p')
    let newP1 = document.createElement('p')
    let newP2 = document.createElement('p')
    let newP3 = document.createElement('p')

    var Totaleglob = monstretuer * 20 + bosstuer * 50 + hrs * 120 + min * 60 + sec

    newP.textContent = "Monstre tu� : "+monstretuer   +" "
    newP1.textContent = "Boss tu�e : " + bosstuer + ""
    newP2.textContent = "Temps pass� "  +(hrs > 9 ? hrs : "0" + hrs) + ":" + (min > 9 ? min : "0" + min) + ":" + (sec > 9 ? sec : "0" + sec);
    newP3.textContent = "Score Total : " + (Totaleglob)

    document.getElementById('lesstates').prepend(newP)
    document.getElementById('lesstates').prepend(newP1)
    document.getElementById('lesstates').prepend(newP2)
    document.getElementById('scorefinal').prepend(newP3)
    listescore = []
    for (let i = 1; i < 7; i++) {
        if (i != 6) {
            if (nomjoueur && localStorage.key(i) == null) {
                localStorage.setItem(nomjoueur, Totaleglob)
            } else if (localStorage.key(i) == null ) {
                localStorage.setItem('joueur' + i, Totaleglob)
                break;
            }
        } else {
            for (let i = 0; i < 5; i++) {
                listescore.push(localStorage.getItem(localStorage.key(i)))
            }
            if (Math.min.apply(null, listescore) < Totaleglob) {
                localStorage.removeItem(localStorage.key((listescore.indexOf(Math.min.apply(null, listescore) + ''))));
                if (nomjoueur) {
                    localStorage.setItem(nomjoueur, Totaleglob)
                } else
                    localStorage.setItem(localStorage.key((listescore.indexOf(Math.min.apply(null, listescore) + ''))), Totaleglob)
            }
            listescore=[]
        }
    }

}

function score() {
    document.getElementById("menugen").style.display = "none";
    document.getElementById('classements').style.display=""

    let score1 = document.createElement('p')
    let score2 = document.createElement('p')
    let score3 = document.createElement('p')
    let score4 = document.createElement('p')
    let score5 = document.createElement('p')
    for (let i = 0; i < 5;i++) {
        listescore.push(localStorage.getItem(localStorage.key(i)))
    }

    score1.textContent = localStorage.key((listescore.indexOf(Math.max.apply(null, listescore) + ''))) + ' -- ' + localStorage.getItem(localStorage.key((listescore.indexOf(Math.max.apply(null, listescore) + ''))))
    listescore[listescore.indexOf(Math.max.apply(null, listescore) + '')] =0
    score2.textContent = localStorage.key((listescore.indexOf(Math.max.apply(null, listescore) + ''))) + ' -- ' + localStorage.getItem(localStorage.key((listescore.indexOf(Math.max.apply(null, listescore) + ''))))
    listescore[listescore.indexOf(Math.max.apply(null, listescore) + '')]=0
    score3.textContent = localStorage.key((listescore.indexOf(Math.max.apply(null, listescore) + ''))) + ' -- ' + localStorage.getItem(localStorage.key((listescore.indexOf(Math.max.apply(null, listescore) + ''))))
    listescore[listescore.indexOf(Math.max.apply(null, listescore) + '')]=0
    score4.textContent = localStorage.key((listescore.indexOf(Math.max.apply(null, listescore) + ''))) + ' -- ' + localStorage.getItem(localStorage.key((listescore.indexOf(Math.max.apply(null, listescore) + ''))))
    listescore[listescore.indexOf(Math.max.apply(null, listescore) + '')]=0
    score5.textContent = localStorage.key((listescore.indexOf(Math.max.apply(null, listescore) + ''))) + ' -- ' + localStorage.getItem(localStorage.key((listescore.indexOf(Math.max.apply(null, listescore) + ''))))
    document.getElementById('scoreclassement').prepend(score5)
    document.getElementById('scoreclassement').prepend(score4)
    document.getElementById('scoreclassement').prepend(score3)
    document.getElementById('scoreclassement').prepend(score2)
    document.getElementById('scoreclassement').prepend(score1)

}